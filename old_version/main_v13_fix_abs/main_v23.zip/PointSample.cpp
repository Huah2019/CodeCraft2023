#include <bits/stdc++.h>
#include <bits/stdc++.h>
using namespace std;
pair<int, int> grid_center(int i, int j) { return {2 * i + 1, 2 * j + 1}; }
void solve()
{
    freopen("maps/2.txt", "r", stdin);
    freopen("1.out", "w", stdout);
    int n = 100;
    vector<string> g(n);
    for (int i = 0; i < n; ++i)
        cin >> g[i];

    int gn = 2 * n + 1;
    vector<vector<int>> grid = vector<vector<int>>(gn, vector<int>(gn));
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            if (g[i][j] == '#')
            {
                int gi, gj;
                tie(gi, gj) = grid_center(i, j);
                for (int dx = -1; dx <= 1; ++dx)
                    for (int dy = -1; dy <= 1; ++dy)
                        grid[gi + dx][gj + dy] = -1;
            }
    for (int i = 0; i < gn; ++i)
        for (int j = 0; j < gn; ++j)
            if (i == 0 || i == gn - 1 || j == 0 || j == gn - 1)
                grid[i][j] = -1;
    auto newGrid = grid;
    for (int i = 1; i < gn - 1; ++i)
    {
        for (int j = 1; j < gn - 1; ++j)
            if (grid[i][j] != -1)
            {
                int k = j;
                while (k + 1 < gn - 1 && grid[i][k + 1] != -1)
                    ++k;
                int len = k - j + 1;
                for (int h = j; h <= k; h += 2)
                {
                    if (len == 5 && h == j + 2)
                        continue;
                    newGrid[i][h] = 1;
                }
                j = k;
            }
    }
    for (int j = 1; j < gn - 1; ++j)
        for (int i = 1; i < gn - 1; ++i)
        {
            if (grid[i][j] != -1)
            {
                int k = i;
                while (k + 1 < gn - 1 && grid[k + 1][j] != -1)
                    ++k;
                int len = k - i + 1;
                for (int h = i; h <= k; h += 2)
                {
                    if (len == 5 && h == i + 2)
                        continue;
                    newGrid[h][j] = 1;
                }
                i = k;
            }
        }
    int sum = 0;
    for (int i = 0; i < gn; ++i)
    {
        for (int j = 0; j < gn; ++j)
            if (newGrid[i][j] == -1)
                cout << '#';
            else if (newGrid[i][j] == 0)
                cout << 'X', ++sum;
            else
                cout << ".";
        cout << '\n';
    }
    cout << sum << '\n';
}
// int main()
// {
//     solve();
// }