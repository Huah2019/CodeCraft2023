#include "Robot.hpp"
using namespace std;

int Robot::getTarget()
{
  if (state == 0)
    return -2;
  if (state == 1)
    return buy;
  return sell;
}
void Robot::fresh() { radius = R[item > 0]; }

void Robot::readState()
{
  std::cin >> pid >> item >> tf >> cf;
  std::cin >> angleSpeed >> v.x >> v.y >> angle;
  std::cin >> p.x >> p.y;
  lineSpeed = v.len();
}
void Robot::readRadar()
{
#ifndef SEMI_VERSION
  for (int i = 0; i < 360; ++i)
    std::cin >> radar[i];
#endif
}
void Robot::updLockInfo()
{
  if (isAttacker() || wait)
  {
    isLock = false;
    return;
  }
  int K = 25;     // 参数1，
  double c = 0.1; // 参数2
  int H = 20;     // 参数3
  if (int(hisVelocity.size()) < K)
    isLock = false;
  else
  {
    int sum = 0;
    for (int i = max(0, int(hisVelocity.size()) - K); i < int(hisVelocity.size()); ++i)
      sum += hisVelocity[i] <= c;
    isLock = sum >= H;
  }
}
