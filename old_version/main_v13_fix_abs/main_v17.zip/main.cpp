#include "Map.hpp"
#include "bits/stdc++.h"
#include "move.hpp"
#include "utils.hpp"
#include <string>
using namespace std;

int sellNum[10];
double moneyJustLossTF = 200000;
double moneyJustLossCF = 200000;

void OK() { std::cout << "OK" << std::endl; }
void readOK()
{
  std::string s;
  std::cin >> s;
  myAssert(s == "OK");
}

auto &mp = Map::instance();
auto &mpFoe = Map::instanceFoe();

void initRobotType()
{
  if (mp.type == 2)
  {
    for (auto &r : mp.robots)
    {
      bool canExcuteTask = false;
      for (Platform &bplat : mp.plats)
      {
        int nextime = bplat.getNextTime();
        for (int area : bplat.validAreas)
        {
          D dis1 = std::max(mp.getEvalDis(r.p, bplat.id, area, 0.45),
                            1.0 * nextime / FPS * MAX_FORWARD_SPEED[mp.role]);
          if (dis1 >= 1e9 - 100)
            continue;

          for (Platform &splat : mp.plats)
          {
            if (splat.canBuy(bplat.sell))
            {
              D dis2 = mp.getEvalDisPP(bplat.id, area, splat.id);
              if (dis2 >= 1e9 - 100)
                continue;
              canExcuteTask = true;
              break;
            }
          }
        }
        if (canExcuteTask)
          break;
      }
      if (!canExcuteTask)
        r.type = 1;
    }
  }
  else if (mp.type == 3)
  {
    mp.robots[2].type = 1;
    mp.robots[3].type = 1;
  }
  else if (mp.type == 4)
  {
    for (auto &r : mp.robots)
      r.type = 1;
  }
  else
  {
    if (mp.role == 0)
    {
      mp.robots[2].type = 1;
      mp.robots[3].type = 1;
    }
  }
}

void init()
{
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);
  std::cout << std::fixed << std::setprecision(12);
  std::cerr << std::fixed << std::setprecision(4);

  std::string str = "BLUE";
#ifndef SEMI_VERSION
  std::cin >> str;
#endif
  int role;
  if (str == "BLUE")
  {
    role = 0;
  }
  else
  {
    myAssert(str == "RED");
    role = 1;
  }
  std::vector<std::string> g(MAP_SIZE);
  for (int i = 0; i < MAP_SIZE; i++)
    std::cin >> g[i];
  mp.init(role, g, true);
  mpFoe.init(role ^ 1, g, false);

  initRobotType();
  Logger::instance().load("logs/log_" + std::to_string(mp.mapId) + ".txt");

  readOK();
  OK();

  dbg("map type:", mp.type);

  dbg("init OK, time:", getTime());
}

int frameID, money;

void sellItem()
{
  for (Robot &r : mp.robots)
    if (r.state == 2 && r.pid == r.sell)
    {
      bool ok = mp.plats[r.pid].buyItem(r.item);
      if (ok)
      {
        ++sellNum[r.item];
        moneyJustLossTF += SELL_PRICE[r.item] * r.tf;
        moneyJustLossCF += SELL_PRICE[r.item] * r.cf;
        r.radius = 0.45;
        r.item = 0;
        r.state = 0;
        std::cout << "sell " << r.id << '\n';
      }
    }
}
void buyItem()
{
  for (Robot &r : mp.robots)
    if (r.state == 1 && r.pid == r.buy)
    {
      bool flag = true;

      if (r.buyPlatArea)
      {
        flag = checkPointArea(r.buyPlatArea, r.p - mp.plats[r.buy].p);
      }

      if (!flag)
        continue;

      double evalTime = frameID +
                        mp.plats[r.buy].p.dis(mp.plats[r.sell].p) /
                            MAX_FORWARD_SPEED[mp.role] * FPS +
                        15;
      if (evalTime > FRAME_LIMIT)
        continue;

      r.item = mp.plats[r.pid].sellItem();
      if (r.item != 0)
      {
        moneyJustLossTF -= BUY_PRICE[r.item];
        moneyJustLossCF -= BUY_PRICE[r.item];
        r.radius = 0.53;
        r.state = 2;
        std::cout << "buy " << r.id << '\n';
      }
    }
    else if (r.isAttacker() && r.attackBuy123 >= 0 && r.attackBuy123 == r.pid)
    {
      r.item = mp.plats[r.pid].sellItem();
      if (r.item != 0)
      {
        moneyJustLossTF -= BUY_PRICE[r.item];
        moneyJustLossCF -= BUY_PRICE[r.item];
        r.radius = 0.53;
        r.attackBuy123 = -2;
        std::cout << "buy " << r.id << '\n';
      }
    }
}

void updTaskForTransporter6()
{
  auto &robots = mp.robots;
  bool transmode = false;
  // if (mp.map_id == 4)
  //     transmode = true;

  std::vector<bool> ok(robots.size());
  int it = robots.size();
  if (frameID > FRAME_LIMIT - 200)
  {
    for (int i = 0; i < robots.size(); ++i)
      if (!robots[i].isTransporter() || robots[i].state)
        ok[i] = true;
  }
  else
  {
    for (auto &rob : robots)
      if (rob.isTransporter())
      {
        if (rob.state == 2)
        {
          if (transmode)
            mp.plats[rob.sell].willBuy ^= 1 << rob.item;
        }
        else if (rob.state == 1)
        {
          mp.plats[rob.sell].willBuy ^= 1 << mp.plats[rob.buy].sell;
          --mp.plats[rob.buy].willSellNum;
        }
      }
  }
  std::vector<int> num(10);
  for (auto &p : mp.plats)
    if (p.type == 7 && (p.alreadyBuy | p.willBuy))
    {
      for (int item = 4; item <= 6; ++item)
        if ((p.needBuy >> item & 1) &&
            !((p.alreadyBuy | p.willBuy) >> item & 1))
          --num[item];
      if (p.num == 0 && p.prodTime != -1 && p.prodTime <= 500)
        for (int item = 4; item <= 6; ++item)
          --num[item];
    }
    else if (p.type >= 4 && p.type <= 6)
    {
      int x = p.num + (p.prodTime != -1) - p.willSellNum;
      num[p.type] += x;
    }
  while (it--)
  {
    double mxScore = 0;
    int rid = -1, bpid = -1, spid = -1, rindex = -1, buyPlatArea = -1;
    for (size_t i = 0; i < robots.size(); ++i)
    {
      auto &rob = robots[i];
      if (!rob.isTransporter() || rob.state == 2 && !transmode)
        ok[i] = true;
      if (ok[i])
        continue;
      if (rob.state == 2)
      {
        for (auto &splat : mp.plats)
        {
          if (splat.isSafe && splat.canBuy(rob.item))
          {
            double dis = rob.p.dis(splat.p);
            double Score = SELL_PRICE[rob.item] / dis + 100000;

            int delta = 25;
            double evalTime =
                frameID + dis / MAX_FORWARD_SPEED[mp.role] * FPS + delta;

            if (Score > mxScore && evalTime <= FRAME_LIMIT)
            {
              mxScore = Score;
              rid = rob.id;
              rindex = i;
              bpid = -1;
              spid = splat.id;
            }
          }
        }
      }
      else
      {
        for (Platform &bplat : mp.plats)
        {
          int nextime = bplat.getNextTime();
          if (nextime == -1 || nextime > 50)
            continue;

          for (int area : bplat.validAreas)
          {
            D dis1 = std::max(mp.getEvalDis(rob.p, bplat.id, area, 0.45),
                              1.0 * nextime / FPS * MAX_FORWARD_SPEED[mp.role]);
            if (dis1 >= 1e9)
              continue;

            for (Platform &splat : mp.plats)
            {
              if (splat.canBuy(bplat.sell))
              {
                D dis2 = mp.getEvalDisPP(bplat.id, area, splat.id);
                if (dis2 >= 1e9)
                  continue;

                double Score =
                    (SELL_PRICE[bplat.sell] - BUY_PRICE[bplat.sell]) /
                    (dis1 + dis2);

                Score *= pow(
                    __builtin_popcount(splat.willBuy | splat.alreadyBuy) + 1,
                    1.5);

                if (bplat.type >= 1 && bplat.type <= 6 && splat.type == 9)
                  Score /= 10;

                if (bplat.type >= 4 && bplat.type <= 6 && splat.type == 9 &&
                    num[bplat.type] <= 1)
                  Score -= 10000;

                Score -= __builtin_popcount(bplat.willBuy) * 1000;

                if (num[splat.type] < 0)
                  Score += 10000;

                int delta = 25;
                double evalTime =
                    frameID + (dis1 + dis2) / MAX_FORWARD_SPEED[mp.role] * FPS +
                    delta;

                if (Score > mxScore && evalTime <= FRAME_LIMIT)
                {
                  mxScore = Score;
                  rid = rob.id;
                  rindex = i;
                  bpid = bplat.id;
                  spid = splat.id;
                  buyPlatArea = area;
                }
              }
            }
          }
        }
      }
    }
    if (rid == -1)
    {
      for (size_t i = 0; i < robots.size(); ++i)
        if (robots[i].isTransporter())
        {
          if (robots[i].state == 2)
            assert(ok[i]);
          else if (!ok[i])
          {
            robots[i].state = 0;
            robots[i].buy = robots[i].sell = -1;
          }
        }
      break;
    }
    ok[rindex] = true;
    auto &rob = robots[rid];
    if (rob.item)
    {
      assert(rob.state == 2);
      auto &splat = mp.plats[spid];
      rob.sell = spid;
      splat.willBuy |= 1 << rob.item;
    }
    else
    {
      auto &bplat = mp.plats[bpid];
      auto &splat = mp.plats[spid];
      rob.buy = bpid;
      rob.buyPlatArea = buyPlatArea;
      rob.sell = spid;
      ++bplat.willSellNum;
      splat.willBuy |= 1 << bplat.sell;
      if (splat.needBuy == (splat.willBuy | splat.alreadyBuy))
        ++num[splat.type];
      rob.state = 1;
    }
  }

  auto swithTarget = [&](Robot &r)
  {
    if (r.sell != -1)
    {
      auto &splat = mp.plats[r.sell];
      if ((splat.willBuy | splat.alreadyBuy) == splat.needBuy)
        --num[splat.type];
      mp.plats[r.sell].willBuy ^= 1 << r.item;
    }
    r.sell = -1;
    double mxScore = -1e9;
    for (auto &splat : mp.plats)
    {
      if (splat.canBuy(r.item))
      {
        double dis = r.p.dis(splat.p);
        double Score = BUY_PRICE[r.item] / dis;

        Score *= pow(
            __builtin_popcount(splat.willBuy | splat.alreadyBuy) + 1,
            1.5);

        if (num[splat.type] < 0)
          Score += 10000;

        int delta = 25;
        double evalTime =
            frameID + dis / MAX_FORWARD_SPEED[mp.role] * FPS + delta;

        if (Score > mxScore && evalTime <= FRAME_LIMIT)
        {
          mxScore = Score;
          r.sell = splat.id;
        }
      }
    }
    if (r.sell != -1)
    {
      auto &splat = mp.plats[r.sell];
      splat.willBuy ^= 1 << r.item;
      if ((splat.willBuy | splat.alreadyBuy) == splat.needBuy)
        ++num[splat.type];
    }
  };

  for (auto &r : robots)
    if (r.isTransporter() && r.state == 2 && (r.sell == -1 || !mp.plats[r.sell].isSafe))
      swithTarget(r);
}

void updTaskForTransporter7()
{
  auto &robots = mp.robots;
  bool transmode = false;
  // if (mp.map_id == 4)
  //     transmode = true;

  std::vector<bool> ok(robots.size());
  int it = robots.size();
  if (frameID > FRAME_LIMIT - 200)
  {
    for (int i = 0; i < robots.size(); ++i)
      if (!robots[i].isTransporter() || robots[i].state)
        ok[i] = true;
  }
  else
  {
    for (auto &rob : robots)
      if (rob.isTransporter())
      {
        if (rob.state == 2)
        {
          if (transmode)
            mp.plats[rob.sell].willBuy ^= 1 << rob.item;
        }
        else if (rob.state == 1)
        {
          mp.plats[rob.sell].willBuy ^= 1 << mp.plats[rob.buy].sell;
          --mp.plats[rob.buy].willSellNum;
        }
      }
  }
  std::vector<int> num(10);
  for (auto &p : mp.plats)
    if (p.type == 7) // todo: 检查7号工作台是否可以完成
    {
      for (int item = 4; item <= 6; ++item)
        if ((p.needBuy >> item & 1) &&
            !((p.alreadyBuy | p.willBuy) >> item & 1))
          --num[item];
      // if (p.num == 0 && p.prodTime != -1 && p.prodTime <= 500)
      //   for (int item = 4; item <= 6; ++item)
      //     --num[item];
    }
    else if (p.type >= 4 && p.type <= 6)
    {
      int x = p.num + (p.prodTime != -1) - p.willSellNum;
      num[p.type] += x;
    }
  // dbg(num[4], num[5], num[6]);

  while (it--)
  {
    double mxScore = -1e9;
    int rid = -1, bpid = -1, spid = -1, rindex = -1, buyPlatArea = -1;
    for (size_t i = 0; i < robots.size(); ++i)
    {
      auto &rob = robots[i];
      if (!rob.isTransporter() || rob.state == 2 && !transmode)
        ok[i] = true;
      if (ok[i])
        continue;
      if (rob.state == 2)
      {
        for (auto &splat : mp.plats)
        {
          if (splat.canBuy(rob.item))
          {
            double dis = rob.p.dis(splat.p);
            double Score = SELL_PRICE[rob.item] / dis + 100000;

            int delta = 25;
            double evalTime =
                frameID + dis / MAX_FORWARD_SPEED[mp.role] * FPS + delta;

            if (Score > mxScore && evalTime <= FRAME_LIMIT)
            {
              mxScore = Score;
              rid = rob.id;
              rindex = i;
              bpid = -1;
              spid = splat.id;
            }
          }
        }
      }
      else
      {
        for (Platform &bplat : mp.plats)
        {
          int nextime = bplat.getNextTime();
          if (nextime == -1 || nextime > 50)
            continue;

          for (int area : bplat.validAreas)
          {
            D dis1 = std::max(mp.getEvalDis(rob.p, bplat.id, area, 0.45),
                              1.0 * nextime / FPS * MAX_FORWARD_SPEED[mp.role]);
            if (dis1 >= 1e9)
              continue;

            for (Platform &splat : mp.plats)
            {
              if (splat.canBuy(bplat.sell))
              {
                D dis2 = mp.getEvalDisPP(bplat.id, area, splat.id);
                if (dis2 >= 1e9)
                  continue;

                double Score =
                    (SELL_PRICE[bplat.sell] - BUY_PRICE[bplat.sell]) /
                    (dis1 + dis2);

                Score *= pow(
                    __builtin_popcount(splat.willBuy | splat.alreadyBuy) + 1,
                    1.5);

                if (bplat.type >= 1 && bplat.type <= 6 && splat.type == 9)
                  Score /= 10;

                if (bplat.type >= 4 && bplat.type <= 6 && splat.type == 9 &&
                    num[bplat.type] <= 1)
                  Score -= 10000;

                Score -= __builtin_popcount(bplat.willBuy) * 1000;

                if (splat.type >= 4 && splat.type <= 6)
                  Score -= 10000 * num[splat.type];
                if (bplat.type >= 4 && bplat.type <= 6 && splat.type == 7)
                  Score -= 10000 * num[bplat.type];

                int delta = 25;
                double evalTime =
                    frameID + (dis1 + dis2) / MAX_FORWARD_SPEED[mp.role] * FPS +
                    delta;

                if (Score > mxScore && evalTime <= FRAME_LIMIT)
                {
                  mxScore = Score;
                  rid = rob.id;
                  rindex = i;
                  bpid = bplat.id;
                  spid = splat.id;
                  buyPlatArea = area;
                }
              }
            }
          }
        }
      }
    }
    if (rid == -1)
    {
      for (size_t i = 0; i < robots.size(); ++i)
        if (robots[i].isTransporter())
        {
          if (robots[i].state == 2)
            assert(ok[i]);
          else if (!ok[i])
          {
            robots[i].state = 0;
            robots[i].buy = robots[i].sell = -1;
          }
        }
      break;
    }
    ok[rindex] = true;
    auto &rob = robots[rid];
    if (rob.item)
    {
      assert(rob.state == 2);
      auto &splat = mp.plats[spid];
      rob.sell = spid;
      splat.willBuy |= 1 << rob.item;
    }
    else
    {
      auto &bplat = mp.plats[bpid];
      auto &splat = mp.plats[spid];
      rob.buy = bpid;
      rob.buyPlatArea = buyPlatArea;
      rob.sell = spid;
      ++bplat.willSellNum;
      splat.willBuy |= 1 << bplat.sell;
      if (splat.needBuy == (splat.willBuy | splat.alreadyBuy))
        ++num[splat.type];
      rob.state = 1;
    }
  }
}

// void updTaskForAttacker()
// {
//   auto interfereFoe = [&](Robot &r)
//   {
//     r.attackFoeId = -1;
//     if (mp.foes.empty())
//       return;
//     double mndis = 1e9;
//     for (int id = 0; id < mp.foes.size(); ++id)
//     {
//       auto &e = mp.foes[id];
//       if (!(e.visibleRobotMask >> r.id & 1))
//         continue;
//       // if (e.velocity.len() <= EPS)
//       //   continue;
//       double angle =
//           normAngle(atan2(e.velocity.y, e.velocity.x) - e.pos.angleTo(r.p));
//       // 参数，距离敌方机器人的距离
//       if (e.pos.dis(r.p) < mndis)
//       {
//         mndis = e.pos.dis(r.p);
//         if (std::abs(angle) <= PI / 2 || e.pos.dis(r.p) <= 0.5)
//           mndis -= 3;
//         r.attackFoeId = id;
//       }
//     }
//   };

//   auto &robots = mp.robots;
//   for (auto &r : robots)
//     if (r.isAttacker())
//     {
//       interfereFoe(r);
//       if (r.attackFoeId != -1)
//         continue;
//       bool last = r.attackPlatId;
//       if (frameID % 3000 == 0)
//         r.attackPlatId = -1;
//       if (r.attackPlatId == -1)
//       {
//         std::vector<int> pids;
//         for (auto &p : mpFoe.plats)
//           if (p.type == 7 && p.id != last)
//             pids.push_back(p.id);
//         if (pids.empty())
//         {
//           for (auto &p : mpFoe.plats)
//             if (p.type == 9 && p.id != last)
//               pids.push_back(p.id);
//         }
//         if (pids.empty())
//         {
//           for (auto &p : mpFoe.plats)
//             if (p.type == 8 && p.id != last)
//               pids.push_back(p.id);
//         }
//         if (pids.empty())
//         {
//           for (auto &p : mpFoe.plats)
//             if (p.type >= 4 && p.type <= 6 && p.id != last)
//               pids.push_back(p.id);
//         }
//         if (pids.empty())
//         {
//           for (auto &p : mpFoe.plats)
//             if (p.id != last)
//               pids.push_back(p.id);
//         }
//         if (pids.empty())
//         {
//           for (auto &p : mpFoe.plats)
//             pids.push_back(p.id);
//         }
//         shuffle(pids.begin(), pids.end(), Random::instance().rng);
//         double mndis = 1e9;
//         for (int pid : pids)
//         {
//           double curdis = mpFoe.getEvalDis(r.p, pid, 0, r.radius);
//           if (r.attackPlatId == -1 ||
//               Random::randDouble(0.5, 1) > 1.0 * (curdis + 1) / (mndis + 1))
//           {
//             mndis = curdis;
//             r.attackPlatId = pid;
//           }
//         }
//       }
//     }
// }

void updTaskForAttacker()
{
  static std::vector<int> foePlatsDensity;
  static std::vector<int> denseFoePlats;
  if (foePlatsDensity.empty() && !mpFoe.plats.empty())
  {
    const double R = 8; // 参数，工作台密度判断范围
    foePlatsDensity.resize(mpFoe.plats.size());
    for (size_t i = 0; i < foePlatsDensity.size(); ++i)
      for (size_t j = 0; j < foePlatsDensity.size(); ++j)
        if (mpFoe.plats[i].p.dis(mpFoe.plats[j].p) <= R)
          ++foePlatsDensity[i];
    int mx = *std::max_element(foePlatsDensity.begin(), foePlatsDensity.end());
    for (int z = mx; z >= mx - 2; --z)
    {
      for (size_t i = 0; i < foePlatsDensity.size(); ++i)
        if (foePlatsDensity[i] >= z && mpFoe.plats[i].type >= 4)
          denseFoePlats.push_back(i);
      if (int(denseFoePlats.size()) >= 3)
        break;
    }
    if (denseFoePlats.empty())
    {
      for (size_t i = 0; i < foePlatsDensity.size(); ++i)
        if (foePlatsDensity[i] == mx)
          denseFoePlats.push_back(i);
    }

    for (auto &r : mp.robots)
      if (r.isAttacker())
      {
        double mnDis = 1e9;
        for (int type = 1; type <= 3; ++type)
        {
          for (auto &bplat : mp.plats)
            if (bplat.type == type)
            {
              double dis1 = mp.getEvalDis(r.p, bplat.id, 0, 0.43);
              if (dis1 >= 1e9 - 100)
                continue;
              for (int spid : denseFoePlats)
              {
                double dis2 = mpFoe.getEvalDis(bplat.p, spid, 0, 0.53);
                if (dis2 >= 1e9 - 100)
                  continue;
                if (dis1 + dis2 < mnDis)
                {
                  mnDis = dis1 + dis2;
                  r.attackBuy123 = bplat.id;
                }
              }
            }
          if (r.attackBuy123 != -1)
            break;
        }
        if (r.attackBuy123 != -1)
          break;
      }
  }

  auto interfereFoe = [&](Robot &r)
  {
    r.attackFoeId = -1;
    if (mp.foes.empty())
      return;
    double mndis = 1e9;
    for (int id = 0; id < mp.foes.size(); ++id)
    {
      auto &e = mp.foes[id];
      if (!(e.visibleRobotMask >> r.id & 1))
        continue;
      // if (e.velocity.len() <= EPS)
      //   continue;
      double angle =
          normAngle(atan2(e.velocity.y, e.velocity.x) - e.pos.angleTo(r.p));
      // 参数，距离敌方机器人的距离
      double dis = e.pos.dis(r.p);
      if (std::abs(angle) > PI / 2 && dis > 3)
        continue;
      if (dis < mndis)
      {
        mndis = e.pos.dis(r.p);
        r.attackFoeId = id;
      }
    }
  };

  auto &robots = mp.robots;
  for (auto &r : robots)
    if (r.isAttacker())
    {

      if (r.attackBuy123 >= 0)
        continue;

      interfereFoe(r);
      if (r.attackFoeId != -1)
        continue;
      if (frameID % 3000 == 0)
        r.attackPlatId = -1;
      if (r.attackPlatId == -1 && !denseFoePlats.empty())
      {
        std::shuffle(denseFoePlats.begin(), denseFoePlats.end(), Random::instance().rng);
        for (int pid : denseFoePlats)
          if (mpFoe.getEvalDis(r.p, pid, 0, r.radius) <= 1e9 - 100)
          {
            r.attackPlatId = denseFoePlats.back();
            break;
          }
      }
    }
}

void updTask()
{
  updTaskForTransporter6();
  // updTaskForTransporter7();
  updTaskForAttacker();
}

void processRadarInfo1()
{
  auto &rs = mp.robots;
  auto isInMyRob = [&](const Pt &p)
  {
    for (auto &r : rs)
    {
      if (p.dis(r.p) <= r.radius + EPS)
        return true;
    }
    return false;
  };

  auto isObst = [&](int i, int j)
  {
    int x = mp.n - 1 - j, y = i;
    return x < 0 || y < 0 || x >= mp.n || y >= mp.n || mp.g[x][y] == '#';
  };
  auto isInObst = [&](const Pt &p)
  {
    // auto os = Obstacle::getNearbyObstaclePoints(mp.g, p, 1);
    // for (auto [x, y] : os) {
    //   if (p.onSeg(Pt(x, y), Pt(x, y + 0.5)) ||
    //       p.onSeg(Pt(x, y), Pt(x + 0.5, y)) ||
    //       p.onSeg(Pt(x, y + 0.5), Pt(x + 0.5, y + 0.5)) ||
    //       p.onSeg(Pt(x + 0.5, y), Pt(x + 0.5, y + 0.5)))
    //     return true;
    // }
    // return false;
    int u = p.x * 2, v = p.y * 2;
    if (isObst(u, v))
      return true;
    if (!cmp(u, p.x * 2))
    {
      return isObst(u - 1, v);
    }
    if (!cmp(v, p.y * 2))
    {
      return isObst(u, v - 1);
    }
    return false;
  };

  std::vector<Foe> fs;

  std::vector<std::vector<Pt>> as(rs.size());
  for (auto &r : rs)
  {
    auto &a = as[r.id];
    a.reserve(360);
    for (int i = 0; i < 360; i++)
    {
      D ang = r.angle + i * PI / 180;
      a[i] = r.p + Pt(std::cos(ang), std::sin(ang)) * r.radar[i];
      if (isInMyRob(a[i]) || isInObst(a[i]))
      {
        a[i].x = -1;
      }
    }

    for (int i = 0; i < 360; i++)
    {
      int j = (i + 1) % 360, k = (i + 2) % 360;
      if (a[i].x < 0 || a[j].x < 0 || a[k].x < 0)
        continue;
      if (!sgn(a[i].cross(a[j], a[k])))
        continue;

      D radius = getRadius(a[i], a[j], a[k]);

      if (std::fabs(radius - R[0]) > 1e-5 && std::fabs(radius - R[1]) > 1e-5)
      {
        continue;
      }

      if (std::fabs(radius - R[0]) < 1e-5)
      {
        radius = R[0];
      }
      if (std::fabs(radius - R[1]) < 1e-5)
      {
        radius = R[1];
      }

      Pt p = getCenter(a[i], a[j], a[k]);

      // if (frameID > 2800 && r.isAttacker()) {
      //   dbg(frameID, r.id, i, p, radius);
      // }

      auto check = [&]
      {
        for (auto &o : fs)
        {
          if (o.pos.dis(p) < 0.1)
            return false;
        }
        for (auto &o : rs)
        {
          if (o.p.dis(p) < 0.1)
            return false;
        }
        return true;
      };

      if (check())
      {
        Pt v;
        for (auto &o : mp.foes)
        {
          if (o.pos.dis(p) <= 0.2)
            v = (p - o.pos) * FPS;
        }
        // if (frameID > 2800 && r.isAttacker())  {
        //   dbg(frameID, r.id, i, p, radius, "ok");
        // }
        fs.emplace_back(p, v, radius, -1);
      }
    }
  }

  // for (auto &f : fs) {
  //   for (auto &r : rs) {
  //     for (auto &p : as[r.id]) {
  //       if (std::fabs(p.dis(f.pos) - f.radius) < 0.01) {
  //         f.visibleRobotMask |= 1 << r.id;
  //         break;
  //       }
  //     }
  //   }
  // }

  mp.foes = fs;

  // if (frameID >= 2800) {
  //   dbg(frameID);
  //   for (auto &r : rs) {
  //     if (r.isAttacker()) {
  //       for (int i = 0; i < 360; i++) {
  //         dbg(frameID, as[r.id][i]);
  //       }
  //     }
  //   }
  //   if (frameID > 2900) exit(0);
  // }

  // fs.clear();
  // if (frameID % 100 == 0) {
  //   Logger log;
  //   std::string name = mp.role ? "RED" : "BLUE";
  //   name += std::to_string(frameID / 100);
  //   log.load(name);
  //   if (mp.role) {
  //     fs = mp.foes;
  //     std::sort(fs.begin(), fs.end(), [&](auto &u, auto &v) {
  //       return u.pos < v.pos;
  //     });

  //     for (auto &o : fs) {
  //       log.write("RED", frameID, o.pos, o.radius, o.velocity);
  //     }
  //     dbg(fs.size());
  //     if (frameID == 800) {
  //       int id = -1;
  //       D maxx = 0;
  //       for (auto &r : rs) {
  //         if (smax(maxx, r.p.x)) id = r.id;
  //       }
  //       auto &v = rs[id].radar;
  //       for (int i = 0; i < 360; i++) {
  //         D ang = rs[id].angle + i * PI / 180;
  //         dbg(i, rs[id].p + Pt(std::cos(ang), std::sin(ang)) * v[i]);
  //       }
  //     }
  //   } else {
  //     for (auto &o : rs) fs.emplace_back(o.p, o.v, o.radius);

  //     std::sort(fs.begin(), fs.end(), [&](auto &u, auto &v) {
  //       return u.pos < v.pos;
  //     });
  //     for (auto &o : fs) {
  //       log.write("BLU", frameID, o.pos, o.radius, o.velocity);
  //     }
  //   }

  // }
}

void processRadarInfo()
{
  auto &robots = mp.robots;
  std::vector<Foe> fs;
  auto isInMyRob = [&](Pt &p)
  {
    for (auto &r : robots)
      if (std::abs(r.p.dis(p) - r.radius) <= EPS)
        return true;
    return false;
  };
  auto isObst = [&](int i, int j)
  {
    int x = mp.n - 1 - j, y = i;
    return x < 0 || y < 0 || x >= mp.n || y >= mp.n || mp.g[x][y] == '#';
  };
  auto isInObst = [&](const Pt &p)
  {
    int u = p.x * 2, v = p.y * 2;
    if (isObst(u, v))
      return true;
    if (!cmp(u, p.x * 2))
    {
      return isObst(u - 1, v);
    }
    if (!cmp(v, p.y * 2))
    {
      return isObst(u, v - 1);
    }
    return false;
  };
  for (size_t i = 0; i < robots.size(); ++i)
  {
    auto &r = robots[i];
    for (int i = 0; i < 360; ++i)
    {
      int j = (i + 1) % 360, k = (i + 2) % 360;
      double angleI = r.angle + 1.0 * i / 180 * PI;
      double angleJ = r.angle + 1.0 * j / 180 * PI;
      double angleK = r.angle + 1.0 * k / 180 * PI;
      Point a = r.p + Point(cos(angleI), sin(angleI)) * r.radar[i];
      Point b = r.p + Point(cos(angleJ), sin(angleJ)) * r.radar[j];
      Point c = r.p + Point(cos(angleK), sin(angleK)) * r.radar[k];
      if (isInObst(a) || isInObst(b) || isInObst(c))
        continue;
      if (isInMyRob(a) || isInMyRob(b) || isInMyRob(c))
        continue;
      if (!sgn(a.cross(b, c)))
        continue;
      double radius = getRadius(a, b, c);
      double EPS1 = 0.00001; // 三点定圆精度设置1
      double EPS2 = 0.001;   // 三点定圆精度设置2
      if (std::abs(radius - 0.45) > EPS1 && std::abs(radius - 0.53) > EPS1)
        continue;
      // radius = std::abs(radius - 0.45) <= EPS1 ? 0.45 : 0.53;
      Pt center = getCenter(a, b, c);
      bool isNotIn = true;
      for (auto &rb : robots)
        if (center.dis(rb.p) <= EPS2)
        {
          isNotIn = false;
          break;
        }
      for (auto &e : fs)
        if (e.pos.dis(center) <= EPS2)
        {
          isNotIn = false;
          e.visibleRobotMask |= 1 << r.id;
        }
      if (isNotIn)
        fs.push_back(Foe(center, Pt(0, 0), radius, 1 << r.id));
    }
  }
  // 每帧最大移动距离为7/50=0.14
  for (auto &e : fs)
    for (auto &eOld : mp.foes)
      if (eOld.pos.dis(e.pos) <= 0.2)
        e.velocity = (e.pos - eOld.pos) * FPS;
  mp.foes = fs;

  // if (int(enemys.size()) > 4)
  // {
  // if (mp.role == 1)
  // {
  //   dbg("enemys num:", mp.enemys.size());
  //   for (auto &e : mp.enemys)
  //     dbg(e.pos.str(), e.velocity.str(), e.radius);
  // }
  // dbg("my Robot:");
  // for (auto &r : robots)
  //   dbg(r.p.str(), r.v.str(), r.radius);
  // }
}
void processHisInfo()
{
  for (auto &plat : mp.plats)
    plat.hisDist.push_back(-1);
  for (auto &e : mp.foes)
    for (auto &plat : mp.plats)
    {
      double edis = mp.getEvalDis(e.pos, plat.id, 0, e.radius);
      if (plat.hisDist.back() < 0 || edis < plat.hisDist.back())
        plat.hisDist.back() = edis;
    }
  for (auto &plat : mp.plats)
    plat.updSafety();

  for (auto &r : mp.robots)
  {
    r.hisVelocity.push_back(r.v.len());
    Point eV = r.nextTo - r.p;
    double ang1 = atan2(eV.y, eV.x);
    double ang2 = atan2(r.v.y, r.v.x);
    const double g = 0.3; // 参数，判断运动方向与期望方向是不是相反
    if (abs(normAngle(ang1 + PI - ang2)) <= g)
      r.hisVelocity.back() *= -1;
    r.updLockInfo();
  }
}

void work()
{
  while (std::cin >> frameID >> money)
  {
    int k;
    std::cin >> k;
    for (Platform &plat : mp.plats)
      plat.readState();
    for (Robot &rob : mp.robots)
      rob.readState();
    for (Robot &rob : mp.robots)
      rob.readRadar();

    readOK();

    std::cout << frameID << '\n';
    processRadarInfo();
    processHisInfo();
    sellItem();
    updTask();
    buyItem();
    moveRobots();
    OK();
  }
}

int main()
{
  init();
  work();

  auto &logger = Logger::instance();
  std::string info = "Sell num for each item:";
  for (int i = 1; i <= 7; ++i)
    info += " " + std::to_string(sellNum[i]);
  logger.write(info);
  info = "Profit upper bound for each item:";
  for (int i = 1; i <= 7; ++i)
    info += " " + std::to_string(sellNum[i] * (SELL_PRICE[i] - BUY_PRICE[i]));
  logger.write(info);

  logger.write("money: " + std::to_string(money));
  int moneyUpperBound = 200000;
  for (int i = 1; i <= 7; ++i)
    moneyUpperBound += (SELL_PRICE[i] - BUY_PRICE[i]) * sellNum[i];
  logger.write("money upper bound: " + std::to_string(moneyUpperBound));
  logger.write("loss money: " + std::to_string(moneyUpperBound - money));
  logger.write("profit rate: " + std::to_string(1.0 * money / moneyUpperBound));
  logger.write("loss rate: " +
               std::to_string(1 - 1.0 * money / moneyUpperBound));
  logger.write("profit_just_loss_tf: " + std::to_string(moneyJustLossTF));
  logger.write("profit_just_loss_cf: " + std::to_string(moneyJustLossCF));
  return 0;
}