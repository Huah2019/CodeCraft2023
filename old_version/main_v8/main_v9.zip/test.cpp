// ConsoleApplication18.cpp : Defines the entry point for the console application.
// 判斷一個點是否在矩形內部

#include "iostream"

struct Point
{
    float x;
    float y;
    Point(float x, float y)
    {
        this->x = x;
        this->y = y;
    }
};
// 計算 |p1 p2| X |p1 p|
float GetCross(Point &p1, Point &p2, Point &p)
{
    return (p2.x - p1.x) * (p.y - p1.y) - (p.x - p1.x) * (p2.y - p1.y);
}
// 判斷點是否在5X5 以原點為左下角的正方形內（便於測試）
Point p1(0, 5);
Point p2(0, 0);
Point p3(5, 0);
Point p4(5, 5);
bool IsPointInMatrix(Point &p)
{

    return GetCross(p1, p2, p) * GetCross(p3, p4, p) >= 0 && GetCross(p2, p3, p) * GetCross(p4, p1, p) >= 0;
    // return false;
}
using namespace std;
int main()
{

    while (true)
    {
        Point testPoint(0, 0);
        cout << "enter  the point :" << endl;

        cin >> p1.x >> p1.y;
        cin >> p2.x >> p2.y;
        cin >> p3.x >> p3.y;
        cin >> p4.x >> p4.y;

        cin >> testPoint.x >> testPoint.y;

        cout << "the point is  : " << testPoint.x << " " << testPoint.y << endl;

        cout << "the point is " << (IsPointInMatrix(testPoint) ? "in the Matrix ." : "not in the matrix .") << endl;
    }

    return 0;
}
//(25.250000,25.400000) (25.250000,26.100000) (25.250000,26.100000) (25.250000,25.400000) (25.250000,25.750000)
// 25.250000 25.400000 25.250000 26.100000 25.250000 26.100000 25.250000 25.400000 25.250000 25.750000
// (25.250000,25.400000) (25.250000,26.100000) (25.150000,26.100000) (25.150000,25.400000) (25.250000,25.750000)
// 25.250000 25.400000 25.250000 26.100000 25.150000 26.100000 25.150000 25.400000 25.250000 25.750000