#pragma once
#include "Map.hpp"
#include <cassert>

constexpr D ROBOT_GAP = -0.05;
constexpr D FOE_GAP = 0.03;

struct AStar {
  const std::vector<int> &foeNeighbors, &robotNeighbors;
  const Pt now;
  const D radius;
  const D dynamicObstHorizon;
  AStar(const std::vector<int> &foeNeighbors,
        const std::vector<int> &robotNeighbors, const Pt &now, D radius,
        D dynamicObstHorizon)
      : foeNeighbors(foeNeighbors), robotNeighbors(robotNeighbors), now(now),
        radius(radius), dynamicObstHorizon(dynamicObstHorizon) {}

  D calExtraCost(Pt a, Pt b, D d) {
    D cost = 0;
    for (int i : foeNeighbors) {
      auto &f = Map::instance().foes[i];
      D dis = distPS(f.pos, a, b);
      D k = dis - f.radius - radius - FOE_GAP;
      if (k <= 0) {
        return 1e9;
      }
      if (f.pos.dis(a) - f.pos.dis(b) > 0.1)
        cost += 2.0 / k;
    }

    if (d < dynamicObstHorizon) {
      Pt v = b - a;
      D vl = v.len();
      for (int i : robotNeighbors) {
        auto &r = Map::instance().robots[i];
        D proj = std::max(0.0, -dot(r.v, v) / vl);
        D dis = distPS(r.p, a, b);
        D k = dis - r.radius - radius - ROBOT_GAP;

        if (proj <= 1 && vl > 0.1) continue;
        if (k <= 0) {
          return 1e9;
        }

        // cost += 1.0 / k;
      }
    }

    return cost;
  }

  bool check(Pt a, Pt b, D d) {
    if (d < dynamicObstHorizon) {
      for (int i : foeNeighbors) {
        auto &f = Map::instance().foes[i];
        if (distPS(f.pos, a, b) <= f.radius + radius + FOE_GAP) {
          return false;
        }
      }
      Pt v = b - a;
      D vl = v.len();
      for (int i : robotNeighbors) {
        auto &r = Map::instance().robots[i];
        D proj = std::max(0.0, -dot(r.v, v) / vl);
        D dis = distPS(r.p, a, b);
        D k = dis - r.radius - radius - ROBOT_GAP;
        if (proj > 0 && proj <= 1 && vl > 0.1) continue;
        if (k <= 0) {
          return false;
        }
      }
    }

    return true;
  }

  struct QInfo {
    D d, v;
    int x;
    bool operator<(const QInfo &r) const { return v > r.v; }
    QInfo(D d, D v, int x) : d(d), v(v), x(x) {}
  };

  template <class F1, class F2>
  std::vector<int> findPath(const Graph &g, const DistInfo &s, F1 &&isTerminal,
                            F2 &&calEvalCost) {
    std::vector<QInfo> d(g.n, QInfo(1e18, 1e18, -1));
    std::vector<D> dist(g.n);

    std::vector<bool> vis(g.n);
    std::priority_queue<QInfo> q;

    for (auto [y, x] : s) {
      d[x] = QInfo(y, y + calEvalCost(x), -1);
      dist[x] = y;
      q.emplace(d[x].d, d[x].v, x);
    }

    while (!q.empty()) {
      QInfo info = q.top();
      q.pop();
      int x = info.x;
      if (isTerminal(x)) {
        std::vector<int> path;
        for (; x != -1; x = d[x].x) {
          path.push_back(x);
        }
        std::reverse(path.begin(), path.end());
        return path;
      }
      if (vis[x])
        continue;
      vis[x] = true;

      for (int i = g.deg[x]; i < g.deg[x + 1]; i++) {
        auto [y, z] = g.g[i];
        if (y == d[x].x)
          continue;

        D extraCost = calExtraCost(g.nodes[x].p, g.nodes[y].p, dist[x]);

        if (extraCost >= 1e9)
          continue;

        // if (d[x].x != -1) {
        //   Pt u = g.nodes[d[x].x].p, v = g.nodes[x].p, w = g.nodes[y].p;
        //   // myAssert(!(u == v) && !(u == w) && !(v == w));
        //   u = v - u, v = w - v;

        //   D ang = std::acos(dot(u, v) / u.len() / v.len());
        //   z += calAngCost(ang, Map::instance().role);
        // }
        if (smin(d[y].d, d[x].d + z + extraCost)) {
          dist[y] = dist[x] + z;
          d[y].v = d[y].d + calEvalCost(y);
          d[y].x = x;
          q.emplace(d[y].d, d[y].v, y);
        }
      }
    }

    return {};
  }

  Pt getNextToPlat(int pid, int area) {
    auto &mp = Map::instance();
    auto &mpFoe = Map::instanceFoe();

    auto path = mp.getPath(now, pid, area, radius);

    if (path.empty())
      return now;

    bool flag = true;
    Pt cur = now;
    D dist = 0;
    for (int i : path) {
      Pt p = mp.nodes[i].p;
      dist += cur.dis(p);
      cur = p;
      if (!check(cur, p, dist)) {
        flag = false;
        break;
      }
    }

    if (!flag) {
      auto ns = mpFoe.getReachableNeighbors(now, radius, 2);

      DistInfo di;
      for (int x : ns) {
        // if (check(now, mpFoe.nodes[x].p, 0)) {
        di.emplace_back(mpFoe.nodes[x].p.dis(now), x);
        // }
      }

      int k = !cmp(radius, R[1]);

      const Pt platPos = mp.plats[pid].p;
      auto &g = *mpFoe.graph[k];
      auto &evalDistInfo = mp.distFromPlat[k][pid][area];
      auto isTerminal = [&](int x) -> bool {
        return g.nodes[x].p.dis2(platPos) <= 0.16;
      };
      auto calEvalCost = [&](int x) -> D { return evalDistInfo[x].first; };
      path = findPath(g, di, isTerminal, calEvalCost);
      if (path.empty())
        return now;

      for (int i = 0; i < path.size(); i++) {
        if (g.nodes[path[i]].p.dis2(platPos) <= 0.49) {
          path.resize(i + 1);
          break;
        }
      }

      for (;;) {
        int x = evalDistInfo[path.back()].second;
        if (x == -1)
          break;
        path.push_back(x);
      }
    }

    for (int i = 1; i < path.size(); i++) {
      Pt p = mp.nodes[path[i]].p;
      if (!check(now, p, now.dis(p)) ||
          !mp.queryReachability(now, p, radius + 0.02)) {
        return mp.nodes[path[i - 1]].p;
      }
    }
    return mp.nodes[path.back()].p;
    // int i = 0;
    // while (check(now, g.nodes[path[i]].p, 0) &&
    //        mpFoe.queryReachability(now, g.nodes[path[i]].p, radius + 0.02))
    //   i++;

    // return g.nodes[path[i - 1]].p;
  }
};
