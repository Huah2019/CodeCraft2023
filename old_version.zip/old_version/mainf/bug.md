disToRob 相对运动时速度为0
