#include "CollisionAvoid.hpp"
#include "Geometry.hpp"
#include "NewMap.hpp"
#include "Platform.hpp"
#include "Robot.hpp"
#include "Tools.hpp"
#include "constants.hpp"
#include "obstacle.hpp"
#include <bits/stdc++.h>
#include <iterator>
#include <random>

using namespace std;
// #define TEST
const int inf = 1e9;
const int map_size = 100;
const int frame_rate = 50;
const int max_frame = 12000 - 50;
const double min_line_speed = -2;
double max_line_speed = 6;
const double min_angle_speed = -pi;
const double max_angle_speed = pi;
const vector<int> buy_price = {0, 3000, 4400, 5800, 15400, 17200, 19200, 76000};
const vector<int> sell_price = {0, 6000, 7600, 9200,
                                22500, 25000, 27500, 105000};
Logger logger;
TimeCounter timeCounter;

double profit_just_loss_tf = 200000;
double profit_just_loss_cf = 200000;
vector<int> sellnum = {0, 0, 0, 0, 0, 0, 0, 0};

vector<long long> hsmaps = {-1, 1530241932764335496ll, 917095264231304242ll,
                            148681776216578555ll, 943576044513860615ll};

int frameID; // 当前帧编号
int money;   // 当前帧收益

vector<Line> edgeLines;
vector<Segment> edgeSegments;

void buildedgeLines()
{
  Point a = Point(0, 0), b = Point(0, 50), c = Point(50, 0), d = Point(50, 50);
  edgeLines.push_back({a, b - a});
  edgeLines.push_back({a, c - a});
  edgeLines.push_back({d, b - d});
  edgeLines.push_back({d, c - d});
  edgeSegments.push_back({a, b});
  edgeSegments.push_back({a, c});
  edgeSegments.push_back({d, b});
  edgeSegments.push_back({d, c});
}

/*
    地图坐标输入格式：
        列从左到右表示x坐标
        行从下到上表示y坐标
    地图坐标表示格式：
        行从上到下表示x坐标
        列从左到右表示y坐标
*/
class Map
{
public:
  void init() { read(MAP_SIZE, MAP_SIZE); }
  int map_id = 0;
  int n; // 行数
  int m; // 列数
  vector<string> origin_map, g;
  vector<Robot> robots;
  vector<Platform> plats;
  int gn, gm;
  bool isok(vector<Segment> &segs, Point s, Point t, double r,
            double p = 0.01)
  {
    Segment sg = {s, t};
    double mndis = 1e9;
    for (auto &s : segs)
      mndis = min(mndis, (double)sg.dis(s));
    return mndis >= r - p;
  };
  /*
  g原坐标：
      列从左到右表示x坐标
      行从下到上表示y坐标
  转换后g的坐标：
      行从上到下表示x坐标
      列从左到右表示y坐标
  */
  void coordinate_transform()
  {
    vector<string> h(m);
    for (int j = 0; j < m; ++j)        // 升序枚举x坐标
      for (int i = n - 1; i >= 0; --i) // 升序枚举y坐标
        h[j] += g[i][j];
    g = h;
    swap(n, m);
  }
  /*
  grid[i][j]=-1:该位置是障碍物
  grid[i][j]=0:(i-0.25,i+0.25),(j-0.25,j+0.25) 范围内不是障碍物
  */
  vector<vector<int>> grid;
  /*
  机器人半径为0.45，距离每个工作站的八联通距离表
  dis45[k][i][j]=inf： 机器人从位置(i,j)不能到达工作台k
  dis45[k][i][j]>=0： 机器人从位置(i,j)到达工作台k的八联通距离
  */
  vector<vector<vector<double>>> dis45;
  /*
  机器人半径为0.53，距离每个工作站的八联通距离表
  dis53[k][i][j]=inf： 机器人从位置(i,j)不能到达工作台k
  dis53[k][i][j]>=0： 机器人从位置(i,j)到达工作台k的八联通距离
  */
  vector<vector<vector<double>>> dis53;
  // 原棋盘(i,j)的中心对应grid中的行列编号
  pair<int, int> grid_center(int i, int j) { return {2 * i + 1, 2 * j + 1}; }
  vector<Segment> aroundObs(Point p, int d = 3)
  {
    int i = p.x / 0.25;
    int j = p.y / 0.25;
    vector<Segment> ans;
    for (int ii = i - d; ii <= i + d; ++ii)
    {
      string info;
      for (int jj = j - d; jj <= j + d; ++jj)
      {
        if (ii >= 0 && ii < gn && jj >= 0 && jj < gm && grid[ii][jj] == -1 &&
            ii % 2 == 1 && jj % 2 == 1)
        {
          ans.push_back({Point((ii - 1) * 0.25, (jj - 1) * 0.25),
                         Point((ii - 1) * 0.25, (jj + 1) * 0.25)});
          ans.push_back({Point((ii - 1) * 0.25, (jj - 1) * 0.25),
                         Point((ii + 1) * 0.25, (jj - 1) * 0.25)});
          ans.push_back({Point((ii + 1) * 0.25, (jj + 1) * 0.25),
                         Point((ii - 1) * 0.25, (jj + 1) * 0.25)});
          ans.push_back({Point((ii + 1) * 0.25, (jj + 1) * 0.25),
                         Point((ii + 1) * 0.25, (jj - 1) * 0.25)});
        }
      }
    }
    return ans;
  }
  vector<Segment> aroundObs(int i, int j, int d = 3)
  {
    vector<Segment> ans;
    for (int ii = i - d; ii <= i + d; ++ii)
    {
      string info;
      for (int jj = j - d; jj <= j + d; ++jj)
      {
        if (ii >= 0 && ii < gn && jj >= 0 && jj < gm && grid[ii][jj] == -1)
        {
          if (ii && grid[ii - 1][jj] == -1)
            ans.push_back({Point((ii - 1) * 0.25, jj * 0.25),
                           Point(ii * 0.25, jj * 0.25)});
          if (jj && grid[ii][jj - 1] == 1)
            ans.push_back({Point(ii * 0.25, (jj - 1) * 0.25),
                           Point(ii * 0.25, jj * 0.25)});
        }
      }
    }
    return ans;
  }
  vector<vector<double>> getdistable(double r, int si, int sj)
  {
    vector<vector<double>> dis(gn, vector<double>(gm, inf));
    struct node
    {
      int x, y;
      double dis;
      bool operator<(const node &o) const { return dis > o.dis; }
    };
    priority_queue<node> q;
    for (int i = si - 1; i <= si + 1; ++i)
      for (int j = sj - 1; j <= sj + 1; ++j)
        if (i >= 0 && i < gn && j >= 0 && j < gm && grid[i][j] != -1)
        {
          dis[i][j] = 0;
          q.push({i, j, 0});
        }

    vector<vector<bool>> vis(gn, vector<bool>(gm));
    while (!q.empty())
    {
      int x = q.top().x, y = q.top().y;
      q.pop();
      if (vis[x][y])
        continue;
      vis[x][y] = true;
      vector<Segment> g = aroundObs(x, y);
      for (int dx = -1; dx <= 1; ++dx)
        for (int dy = -1; dy <= 1; ++dy)
          if (dx || dy)
          {
            int xx = x + dx;
            int yy = y + dy;
            if (!(xx >= 0 && xx < gn && yy >= 0 && yy < gm))
              continue;
            double d =
                (Point(x * 0.25, y * 0.25) - Point(xx * 0.25, yy * 0.25)).len();
            if (dis[xx][yy] > dis[x][y] + d && grid[xx][yy] != -1)
            {
              if (!isok(g, Point(x * 0.25, y * 0.25),
                        Point(xx * 0.25, yy * 0.25), r))
                continue;
              dis[xx][yy] = dis[x][y] + d;
              q.push({xx, yy, dis[xx][yy]});
            }
          }
    }
    return dis;
  };
  void buildgrid()
  {
    gn = 2 * n + 1;
    gm = 2 * m + 1;
    grid = vector<vector<int>>(gn, vector<int>(gm));
    for (int i = 0; i < n; ++i)
      for (int j = 0; j < m; ++j)
        if (g[i][j] == '#')
        {
          int gi, gj;
          tie(gi, gj) = grid_center(i, j);
          for (int dx = -1; dx <= 1; ++dx)
            for (int dy = -1; dy <= 1; ++dy)
              grid[gi + dx][gj + dy] = -1;
        }
    for (int j = m - 1; j >= 0; --j) // 工作台按y坐标从大到小为第一优先级编号
      for (int i = 0; i < n; ++i)    // 工作台按x坐标从小达到为第二优先级编号
        if (g[i][j] >= '1' && g[i][j] <= '9')
        {
          int gi, gj;
          tie(gi, gj) = grid_center(i, j);
          dis45.push_back(getdistable(0.45, gi, gj));
          dis53.push_back(getdistable(0.53, gi, gj));
        }
  }
  // 按坐标转换前的行列顺序对机器人和工作台编号，注意在坐标转换前调用
  void getrobandplatinfo()
  {
    auto st = [&](vector<int> vc)
    {
      int ret = 0;
      for (int val : vc)
        ret += 1 << val;
      return ret;
    };
    const vector<int> need_times = {-1, 50, 50, 50, 500, 500, 500, 1000, 1, 1};
    const vector<int> need_buys = {-1, 0,
                                   0, 0,
                                   st({1, 2}), st({1, 3}),
                                   st({2, 3}), st({4, 5, 6}),
                                   st({7}), st({1, 2, 3, 4, 5, 6, 7})};
    const vector<int> sells = {-1, 1, 2, 3, 4, 5, 6, 7, 0, 0};
    for (int i = 0; i < n; ++i)
    {
      string &s = g[i];
      for (int j = 0; j < m; ++j)
      {
        double x = j * 0.5 + 0.25;
        double y = (n - 1 - i) * 0.5 + 0.25;
        if (s[j] == 'A')
        {
          int id = robots.size();
          robots.emplace_back(Robot(id, x, y));
        }
        else if (s[j] >= '1' && s[j] <= '9')
        {
          int id = plats.size();
          int type = s[j] - '0';
          plats.emplace_back(Platform(id, type, need_times[type],
                                      need_buys[type], sells[type], 1, x, y));
        }
        else
          assert(s[j] == '.' || s[j] == '#');
      }
    }
  }
  void read(int _n, int _m)
  {
    n = _n;
    m = _m;
    g.resize(n);
    for (int i = 0; i < n; ++i)
    {
      cin >> g[i];
      assert(int(g[i].size()) == m);
    }
    origin_map = g;
    getrobandplatinfo();
    coordinate_transform();
    buildgrid();
  }
  // 地图哈希值
  long long geths()
  {
    const int mod1 = 998244353, mod2 = 1e9 + 7;
    const int base1 = 2333, base2 = 3931;
    int hs1 = 0, hs2 = 0;
    for (auto &row : g)
      for (char c : row)
      {
        hs1 = (1ll * hs1 * base1 + c) % mod1;
        hs2 = (1ll * hs2 * base2 + c) % mod2;
      }
    return 1ll * hs1 * 2000000000 + hs2;
  }
  Point getNextTo(Point cur, int pid, double r, vector<Segment> &segs)
  {
    // myAssert(pid >= 0);
    auto &dis = abs(r - 0.45) <= 0.001 ? dis45 : dis53;
    int i = cur.x / 0.25;
    int j = cur.y / 0.25;
    double mndis = inf;
    // logger.write("Cur: " + cur.str());
    // logger.write("(" + to_string(i) + "," + to_string(j) + ")");
    int d = 8;
    Point to = cur;
    vector<Segment> g = aroundObs(cur, d + 2);
    for (int ii = i - d; ii <= i + d; ++ii)
    {
      // string info;
      for (int jj = j - d; jj <= j + d; ++jj)
        if (ii >= 0 && ii < gn && jj >= 0 && jj < gm)
        {
          Point tmp(ii * 0.25, jj * 0.25);
          double cost = pid >= 0 ? dis[pid][ii][jj] : inf;
          Segment ss = {cur, tmp};
          if (!segs.empty())
          {
            double dis1 = 1e9, dis2 = 1e9;

            double f = 1.3, g = 2.5;

            if (map_id != 1)
              // f = 2, g = 4;
              f = 1.5, g = 4;

            for (auto &s : segs)
              if (s.dis(ss) < f)
              {
                dis1 = min(dis1, (double)s.dis(tmp));
                dis2 = min(dis2, (double)s.dis(cur));
              }
            if (dis2 <= g)
              cost = -(dis1 - dis2) * 66666;
          }
          if (cost < mndis && isok(g, cur, tmp, r))
          {
            mndis = cost;
            to = tmp;
          }
        }
      // logger.write(info);
    }
    // logger.write("NEX: " + cur.str() + " mndis: " + to_string(mndis));
    return to;
  }
  bool can_to(Point cur, int pid, double r)
  {
    auto &dis = abs(r - 0.45) <= 0.001 ? dis45 : dis53;
    int i = cur.x / 0.25;
    int j = cur.y / 0.25;
    int d = 2;
    for (int ii = i - d; ii <= i + d; ++ii)
      for (int jj = j - d; jj <= j + d; ++jj)
        if (ii >= 0 && ii < gn && jj >= 0 && jj < gm &&
            dis[pid][ii][jj] < inf - 1000)
          return true;
    return false;
  }
  double getEvalDis(Point p, int pid, double r)
  {
    auto &dis = abs(r - 0.45) <= 0.001 ? dis45 : dis53;
    int i = p.x / 0.25;
    int j = p.y / 0.25;
    int d = 1;
    double ans = inf;
    if (pid == -1)
      return ans;
    for (int ii = i - d; ii <= i + d; ++ii)
      for (int jj = j - d; jj <= j + d; ++jj)
        if (ii >= 0 && ii < gn && jj >= 0 && jj < gm)
          ans = min(ans, dis[pid][ii][jj] + Point(ii * 0.25, jj * 0.25).dis(p));
    return ans;
  }
  double getEvalDis(Robot &rob)
  {
    return getEvalDis(rob.p, rob.pid, rob.radius);
  }
};

// Map mp;

NewMap &mp = NewMap::instance();

// ###  TaskApply begin
class TaskManager
{
public:
  vector<int> level456; // 456工作台的优先级
  vector<vector<int>> production_pids;
  vector<pair<int, int>> apply_task(Robot &); // 机器人申请一个任务
  TaskManager()
  {
    production_pids = vector<vector<int>>(8);
    level456 = vector<int>(3);
  }
} task_manager;
vector<vector<int>> plat_ids;                // 每种类型的平台id
vector<vector<pair<int, double>>> sell_pids; // 每个平台可以卖往的平台id和距离
vector<vector<pair<int, double>>> buy_pids;  // 每个平台可以买的平台id和距离
void buildTaskManager()
{
  plat_ids.resize(10);
  sell_pids.resize(mp.plats.size());
  buy_pids.resize(mp.plats.size());
  for (Platform &plat : mp.plats)
    if (plat.active)
    {
      plat_ids[plat.type].push_back(plat.id);
      for (Platform &plt : mp.plats)
      {
        if (plt.need_buy >> plat.sell & 1)
          sell_pids[plat.id].push_back({plt.id, plt.p.dis(plat.p)});
        if (plat.need_buy >> plt.sell & 1)
          buy_pids[plat.id].push_back({plt.id, plt.p.dis(plat.p)});
      }
      sort(sell_pids[plat.id].begin(), sell_pids[plat.id].end(),
           [&](pair<int, double> &x, pair<int, double> &y)
           {
             if (mp.plats[x.first].type != mp.plats[y.first].type)
               return mp.plats[x.first].type < mp.plats[y.first].type;
             return x.second < y.second;
           });
      sort(buy_pids[plat.id].begin(), buy_pids[plat.id].end(),
           [&](pair<int, double> &x, pair<int, double> &y)
           {
             return x.second < y.second;
           });
    }
}

vector<pair<int, int>> TaskManager::apply_task(Robot &rob)
{
  // std::vector<std::vector<int>> canToRP(mp.robots.size());
  // std::vector<std::vector<int>> canToPP(mp.plats.size());
  // for (auto &r : mp.robots) {
  //   canToRP[r.id].resize(mp.plats.size());
  //   for (int k = 0; k < 2; k++) {
  //     auto ns = mp.getReachableNeighbors(r.p, R[k]);
  //     for (auto &p : mp.plats) {
  //       for (int o : ns) {
  //         if (mp.distFromPlat[k][p.id][o].first < 1e9) {
  //           canToRP[r.id][p.id] |= 1 << k;
  //           break;
  //         }
  //       }
  //     }
  //   }
  // }
  // for (auto &r : mp.plats) {
  //   canToPP[r.id].resize(mp.plats.size());
  //   for (int k = 0; k < 2; k++) {
  //     auto ns = mp.getReachableNeighbors(r.p, R[k]);
  //     for (auto &p : mp.plats) {
  //       for (int o : ns) {
  //         if (mp.distFromPlat[k][p.id][o].first < 1e9) {
  //           canToPP[r.id][p.id] |= 1 << k;
  //           break;
  //         }
  //       }
  //     }
  //   }
  // }

  // auto can_to_rp = [&](int rid, int pid, int k) {
  //   return canToRP[rid][pid] >> k & 1;
  // };
  // auto can_to_pp = [&](int pid1, int pid2, int k) {
  //   return canToPP[pid1][pid2] >> k & 1;
  // };

  // sell type 7
  if (!production_pids[7].empty())
  {
    int type = 7;
    double mnScore = 1e9;
    int r_pid = -1;
    for (int pid : production_pids[type])
    {
      Platform &plat = mp.plats[pid];

      // if (!can_to_rp(rob.id, pid, 0))
      if (!mp.can_to(rob.p, pid, 0.45))
        continue;

      int time = plat.getnextime();
      if (time == -1)
        continue;
      double dis = rob.p.dis(plat.p);
      int spid = sell_pids[plat.id].begin()->first;
      double sdis = sell_pids[plat.id].begin()->second;
      int prod = plat.sell;

      if (time <= 100 && dis / max_line_speed * frame_rate + 50 >= time)
      {
        // logger.write("DIS: " + to_string(rob.id) + " " + to_string(dis *
        // frame_rate + 10) + " TIME: " + to_string(time));
        double Score = (dis + sdis) / (sell_price[prod] - buy_price[prod]);
        if (Score < mnScore)
        {
          mnScore = Score;
          r_pid = pid;
        }
      }
    }
    if (r_pid != -1)
    {
      pair<int, int> ans = {-1, -1};
      for (int &pid : production_pids[type])
        if (pid == r_pid)
        {
          Platform &plat = mp.plats[pid];
          plat.will_sell_num++;
          int spid = sell_pids[plat.id].begin()->first;
          // if (!can_to_pp(plat.id, spid, 1))
          if (!mp.can_to(plat.p, spid, 0.53))
            continue;
          ans = {pid, spid};
          pid = production_pids[type].back();
          production_pids[type].pop_back();
          break;
        }
      if (ans.first != -1)
        return {ans};
    }
  }
  // sell type 4,5,6 to 7
  if (!plat_ids[7].empty())
  {
    sort(plat_ids[7].begin(), plat_ids[7].end(), [&](int x, int y)
         { return __builtin_popcount(mp.plats[x].alreay_buy | mp.plats[x].will_buy) >
                  __builtin_popcount(mp.plats[y].alreay_buy | mp.plats[y].will_buy); });

    // if (frameID == 2493)
    // {
    //     int pid = production_pids[6][0];
    //     logger.write("time: " + to_string(mp.plats[pid].getnextime()));
    //     logger.write("will_sell_num: " +
    //     to_string(mp.plats[pid].will_sell_num)); logger.write("num: " +
    //     to_string(mp.plats[pid].num));
    // }

    for (int spid : plat_ids[7])
    {
      double mnScore = 1e9;
      int r_pid = -1, r_spid = spid, r_type = -1;

      for (int type = 4; type <= 6; ++type)
        if (!((mp.plats[spid].alreay_buy | mp.plats[spid].will_buy) >> type &
              1) &&
            !production_pids[type].empty())
        {
          for (int pid : production_pids[type])
          {
            Platform &plat = mp.plats[pid];

            // if (can_to_rp(rob.id, pid, 0))
            if (!mp.can_to(rob.p, pid, 0.45))
              continue;
            // if (can_to_pp(plat.id, spid, 1))
            if (!mp.can_to(plat.p, spid, 0.53))
              continue;

            int time = plat.getnextime();

            if (time == -1)
              continue;
            double dis = rob.p.dis(plat.p);
            int prod = plat.sell;
            assert(prod == type);

            double sdis = sell_pids[plat.id].begin()->second;
            Platform &plt = mp.plats[spid];

            if (time <= 50 && dis / max_line_speed * frame_rate + 50 >= time)
            {
              double Score =
                  (dis + sdis) / (sell_price[prod] - buy_price[prod]);
              // Score -= 500 * __builtin_popcount(mp.plats[spid].alreay_buy |
              // mp.plats[spid].will_buy);
              if (Score < mnScore)
              {
                mnScore = Score;
                r_pid = pid;
                r_spid = spid;
                r_type = type;
              }
            }
          }
        }
      if (r_pid != -1)
      {
        vector<pair<int, int>> ans;
        for (int &pid : production_pids[r_type])
          if (pid == r_pid)
          {
            Platform &plat = mp.plats[pid];
            plat.will_sell_num++;
            pid = production_pids[r_type].back();
            production_pids[r_type].pop_back();
            break;
          }
        // if (mp.map_id == 2 && frameID <= 7000)
        //     for (size_t it = 0; it < buy_pids[r_pid].size(); ++it)
        //     {
        //         int pid = buy_pids[r_pid][it].first;
        //         double dis = buy_pids[r_pid][it].second;
        //         if (((mp.plats[r_pid].alreay_buy | mp.plats[r_pid].will_buy)
        //         >> mp.plats[pid].sell & 1) || !(mp.plats[r_pid].need_buy >>
        //         mp.plats[pid].sell & 1))
        //             continue;
        //         int time = mp.plats[pid].getnextime();
        //         if (time == -1)
        //             continue;

        //         mp.plats[r_pid].will_buy |= 1 << mp.plats[pid].sell;
        //         ++mp.plats[pid].will_sell_num;
        //         ans.push_back({pid, r_pid});
        //     }
        // if (mp.map_id == 2 && mp.plats[r_pid].type != 7)
        //     --level456[mp.plats[r_pid].type - 4];
        mp.plats[r_spid].will_buy |= 1 << r_type;
        ans.push_back({r_pid, r_spid});
        return ans;
      }
    }
  }
  else if (frameID >= max_frame - 2000)
  { // sell 4,5,6 to 9
    for (int spid : plat_ids[9])
    {
      double mnScore = 1e9;
      int r_pid = -1, r_spid = spid, r_type = -1;

      for (int type = 4; type <= 6; ++type)
        if (!production_pids[type].empty())
        {
          for (int pid : production_pids[type])
          {
            Platform &plat = mp.plats[pid];
            // if (!can_to_rp(rob.id, pid, 0))
            if (!mp.can_to(rob.p, pid, 0.45))
              continue;
            // if (can_to_pp(plat.id, spid, 1))
            if (!mp.can_to(plat.p, spid, 0.53))
              continue;

            int time = plat.getnextime();

            if (time == -1)
              continue;
            double dis = rob.p.dis(plat.p);
            int prod = plat.sell;
            assert(prod == type);

            double sdis = sell_pids[plat.id].begin()->second;
            Platform &plt = mp.plats[spid];

            if (time <= 100 && dis / max_line_speed * frame_rate + 50 >= time)
            {
              double Score =
                  (dis + sdis) / (sell_price[prod] - buy_price[prod]);
              if (Score < mnScore)
              {
                mnScore = Score;
                r_pid = pid;
                r_spid = spid;
                r_type = type;
              }
            }
          }
        }
      if (r_pid != -1)
      {
        vector<pair<int, int>> ans;
        for (int &pid : production_pids[r_type])
          if (pid == r_pid)
          {
            Platform &plat = mp.plats[pid];
            plat.will_sell_num++;
            pid = production_pids[r_type].back();
            production_pids[r_type].pop_back();
            break;
          }
        for (size_t it = 0; it < buy_pids[r_pid].size(); ++it)
        {
          int pid = buy_pids[r_pid][it].first;
          double dis = buy_pids[r_pid][it].second;
          if (((mp.plats[r_pid].alreay_buy | mp.plats[r_pid].will_buy) >>
                   mp.plats[pid].sell &
               1) ||
              !(mp.plats[r_pid].need_buy >> mp.plats[pid].sell & 1))
            continue;
          int time = mp.plats[pid].getnextime();
          if (time == -1)
            continue;

          mp.plats[r_pid].will_buy |= 1 << mp.plats[pid].sell;
          ++mp.plats[pid].will_sell_num;
          ans.push_back({pid, r_pid});
        }
        if (mp.map_id == 2 && mp.plats[r_pid].type != 7)
          --level456[mp.plats[r_pid].type - 4];
        mp.plats[r_spid].will_buy |= 1 << r_type;
        ans.push_back({r_pid, r_spid});
        return ans;
      }
    }
  }
  // sell 1,2,3 to 4,5,6
  {
    vector<int> types = {4, 5, 6};
    stable_sort(types.begin(), types.end(), [&](int x, int y)
                { return level456[x - 4] < level456[y - 4]; });
    for (int type : types)
    {
      double mnScore = 1e9;
      int r_pid = -1, r_spid = -1, r_prod = -1;
      for (int spid : plat_ids[type])
      {
        Platform &plt = mp.plats[spid];

        for (int prod = 1; prod <= 3; ++prod)
          if ((plt.need_buy >> prod & 1) &&
              !((plt.alreay_buy | plt.will_buy) >> prod & 1))
          {
            double mndis = 1e9;
            for (int _pid : production_pids[prod])
            {
              Platform &plat = mp.plats[_pid];

              // if (!can_to_rp(rob.id, _pid, 0))
              if (!mp.can_to(rob.p, _pid, 0.45))
                continue;
              // if (!can_to_pp(plat.id, spid, 1))
              if (!mp.can_to(plat.p, spid, 0.53))
                continue;

              double Score = rob.p.dis(plat.p) + plat.p.dis(plt.p);
              Score -= 1000 * __builtin_popcount(plt.alreay_buy | plt.will_buy);
              if (Score < mnScore)
              {
                mnScore = Score;
                r_pid = _pid;
                r_spid = spid;
                r_prod = prod;
              }
            }
          }
      }
      if (r_spid != -1)
      {
        for (int &pid : production_pids[r_prod])
          if (pid == r_pid)
          {
            Platform &plat = mp.plats[pid];
            plat.will_sell_num++;
            pid = production_pids[r_prod].back();
            production_pids[r_prod].pop_back();
            break;
          }

        mp.plats[r_spid].will_buy |= 1 << r_prod;
        if ((mp.plats[r_spid].will_buy | mp.plats[r_spid].alreay_buy) ==
            mp.plats[r_spid].need_buy)
          ++level456[mp.plats[r_spid].type - 4];
        return {{r_pid, r_spid}};
      }
    }
  }
  // if (mp.map_id != 1)
  // {
  //     vector<int> types = {4, 5, 6};
  //     stable_sort(types.begin(), types.end(), [&](int x, int y)
  //                 { return level456[x - 4] < level456[y - 4]; });
  //     for (int type : types)
  //     {
  //         double mnScore = 1e9;
  //         int r_pida = -1, r_pidb = -1, r_spid = -1, r_proda = -1, r_prodb =
  //         -1; for (int spid : plat_ids[type])
  //         {
  //             Platform &plt = mp.plats[spid];
  //             if (plt.alreay_buy | plt.will_buy)
  //                 continue;

  //             int proda = -1, prodb = -1;
  //             for (int prod = 1; prod <= 3; ++prod)
  //                 if ((plt.need_buy >> prod & 1))
  //                     if (proda != -1)
  //                         assert(prodb == -1), prodb = prod;
  //                     else
  //                         proda = prod;

  //             assert(proda != -1 && prodb != -1);
  //             if (production_pids[proda].empty() ||
  //             production_pids[prodb].empty())
  //                 continue;

  //             int pida = -1, pidb = -1;
  //             double mndisa = 1e9, mndisb = 1e9;
  //             for (int _pida : production_pids[proda])
  //             {
  //                 Platform &plat = mp.plats[_pida];
  //                 double dis = plat.p.dis(plt.p);
  //                 if (dis < mndisa)
  //                 {
  //                     mndisa = dis;
  //                     pida = _pida;
  //                 }
  //             }
  //             for (int _pidb : production_pids[prodb])
  //             {
  //                 Platform &plat = mp.plats[_pidb];
  //                 double dis = plat.p.dis(plt.p);
  //                 if (dis < mndisb)
  //                 {
  //                     mndisb = dis;
  //                     pidb = _pidb;
  //                 }
  //             }
  //             assert(pida != -1 && pidb != -1);

  //             double Scoreab = rob.p.dis(mp.plats[pida].p) + mndisa + 2 *
  //             mndisb; double Scoreba = rob.p.dis(mp.plats[pidb].p) + mndisb +
  //             2 * mndisa; double Score = Scoreab; if (Scoreba < Score)
  //             {
  //                 Score = Scoreba;
  //                 swap(pida, pidb);
  //                 swap(proda, prodb);
  //                 swap(mndisa, mndisb);
  //             }
  //             if (Score < mnScore)
  //             {
  //                 mnScore = Score;
  //                 r_pida = pida;
  //                 r_pidb = pidb;
  //                 r_spid = spid;
  //                 r_proda = proda;
  //                 r_prodb = prodb;
  //             }
  //         }
  //         if (r_spid != -1)
  //         {
  //             for (int &pid : production_pids[r_proda])
  //                 if (pid == r_pida)
  //                 {
  //                     Platform &plat = mp.plats[pid];
  //                     plat.will_sell_num++;
  //                     pid = production_pids[r_proda].back();
  //                     production_pids[r_proda].pop_back();
  //                     break;
  //                 }
  //             for (int &pid : production_pids[r_prodb])
  //                 if (pid == r_pidb)
  //                 {
  //                     Platform &plat = mp.plats[pid];
  //                     plat.will_sell_num++;
  //                     pid = production_pids[r_prodb].back();
  //                     production_pids[r_prodb].pop_back();
  //                     break;
  //                 }
  //             mp.plats[r_spid].will_buy = mp.plats[r_spid].need_buy;
  //             ++level456[mp.plats[r_spid].type - 4];
  //             return {{r_pida, r_spid}, {r_pidb, r_spid}};
  //         }
  //     }
  // }
  // else
  // {
  //     vector<int> types = {4, 5, 6};
  //     stable_sort(types.begin(), types.end(), [&](int x, int y)
  //                 { return level456[x - 4] < level456[y - 4]; });
  //     for (int type : types)
  //     {
  //         double mnScore = 1e9;
  //         for (int r_pid : plat_ids[type])
  //         {
  //             vector<pair<int, int>> ans;
  //             for (size_t it = 0; it < buy_pids[r_pid].size(); ++it)
  //             {
  //                 int pid = buy_pids[r_pid][it].first;
  //                 double dis = buy_pids[r_pid][it].second;
  //                 if (((mp.plats[r_pid].alreay_buy |
  //                 mp.plats[r_pid].will_buy) >> mp.plats[pid].sell & 1) ||
  //                 !(mp.plats[r_pid].need_buy >> mp.plats[pid].sell & 1))
  //                     continue;
  //                 int time = mp.plats[pid].getnextime();
  //                 if (time == -1)
  //                     continue;

  //                 mp.plats[r_pid].will_buy |= 1 << mp.plats[pid].sell;
  //                 ++mp.plats[pid].will_sell_num;
  //                 ans.push_back({pid, r_pid});
  //             }
  //             if ((mp.plats[r_pid].alreay_buy | mp.plats[r_pid].will_buy) ==
  //             mp.plats[r_pid].need_buy)
  //                 ++level456[type - 4];
  //             if (!ans.empty())
  //                 return ans;
  //         }
  //     }
  // }
  // sell 1,2,3 to 9
  for (int type : {9})
  {
    double mnScore = 1e9;
    int r_pid = -1, r_spid = -1, r_type = -1;
    for (int spid : plat_ids[type])
    {
      Platform &plt = mp.plats[spid];
      for (int prod = 1; prod <= 3; ++prod)
        if ((plt.need_buy >> prod & 1) &&
            !((plt.alreay_buy | plt.will_buy) >> prod & 1))
        {
          for (int pid : production_pids[prod])
          {
            Platform &plat = mp.plats[pid];

            // if (!can_to_rp(rob.id, pid, 0))
            if (!mp.can_to(rob.p, pid, 0.45))
              continue;
            // if (can_to_pp(plat.id, spid, 1))
            if (!mp.can_to(plat.p, spid, 0.53))
              continue;
            double Score = (rob.p.dis(plat.p) + plat.p.dis(plt.p)) /
                           (sell_price[prod] - buy_price[prod]);
            if (Score < mnScore)
            {
              mnScore = Score;
              r_pid = pid;
              r_spid = spid;
              r_type = prod;
            }
          }
        }
    }
    if (r_pid != -1)
    {
      for (int &pid : production_pids[r_type])
        if (pid == r_pid)
        {
          Platform &plat = mp.plats[pid];
          plat.will_sell_num++;
          pid = production_pids[r_type].back();
          production_pids[r_type].pop_back();
          break;
        }
      return {{r_pid, r_spid}};
    }
  }
  return {};
}

// ### TaskApply end

void readok()
{
  string s;
  cin >> s;
  assert(s == "OK");
}

void readmap()
{
  mp.init();
  if (mp.role == "RED")
    max_line_speed = 7;
  // mp.read(map_size, map_size);
  long long hs = mp.geths();
  for (int i = 1; i < hsmaps.size(); ++i)
    if (hs == hsmaps[i])
      mp.map_id = i;

  std::cerr << "mapid " << mp.map_id << "\n";
}
// ### Platform begin
void Platform::apply_visit(int rid) { apply_visit_list.push_back(rid); }
void Platform::fresh_visit()
{
  if (visit_robot_id == -1)
    return;
  auto &rob = mp.robots[visit_robot_id];
  if (rob.get_target() != id && rob.p.dis(p) >= 1)
    visit_robot_id = -1;
}
void Platform::process_apply_visit_list()
{
  if (visit_robot_id != -1)
    return;
  double mnScore = 1e9;
  for (int rid : apply_visit_list)
  {
    auto &rob = mp.robots[rid];
    double delta = 1;
    double Score = delta;
    if (rob.item)
      Score += sell_price[rob.item] + delta;
    Score = rob.p.dis(p) / Score;
    if (Score < mnScore)
    {
      mnScore = Score;
      visit_robot_id = rid;
    }
  }
  apply_visit_list.clear();
}

bool Platform::can_buy(int item)
{
  if (!active)
    return false;
  if (mp.map_id != 4 && __builtin_popcount(will_buy) >= 1)
    return false;
  return (need_buy >> item & 1) && !((alreay_buy | will_buy) >> item & 1);
}

bool Platform::is_wait() { return prod_time == 0 && num == capacity; }

void Platform::readState()
{
  int prev_prod_time = prod_time;
  int _type;
  double _x;
  double _y;
  cin >> _type >> _x >> _y;
  assert(_type == type);
  assert(abs(p.x - _x) < 1e-6);
  assert(abs(p.y - _y) < 1e-6);
  cin >> prod_time >> alreay_buy >> num;
  if (active && type >= 1 && type <= 7 && prod_time >= need_time - 1 &&
      prev_prod_time <= 0 && !sell_pids[id].empty())
    task_manager.production_pids[type].push_back(id);

  // if (type == 7)
  // {
  //     logger.write("FrameID: " + to_string(frameID));
  //     auto bin = [&](int x)
  //     {
  //         string ans;
  //         for (int i = 7; i >= 1; --i)
  //             if (x >> i & 1)
  //                 ans += '1';
  //             else
  //                 ans += '0';
  //         return ans;
  //     };
  //     logger.write("id: " + to_string(id) + " already_buy " + bin(alreay_buy)
  //     + " will_buy: " + bin(will_buy));
  // }
}

bool Platform::buyitem(int item)
{
  assert(need_buy >> item & 1);
  if (!(alreay_buy >> item & 1))
  {
    alreay_buy |= 1 << item;
    if (will_buy >> item & 1)
      will_buy ^= 1 << item;
    return true;
  }
  return false;
}

int Platform ::sellitem()
{
  if (!num)
    return 0;
  --num;
  --will_sell_num;
  return sell;
}

int Platform ::getnextime()
{
  if (!active)
    return -1;
  // if (will_sell_num)
  //     return -1;
  if (will_sell_num < num)
    return 0;
  if (will_sell_num == num)
    return prod_time;
  return -1;
}
// ### Platform end

// ### Robot begin
inline bool Robot::isBuyAction()
{
  return !tasks.empty() && tasks.front().action == 1;
}
inline bool Robot::isSellAction()
{
  return !tasks.empty() && tasks.front().action == 2;
}
void Robot::addSellTask(int pid)
{
  tasks.push({-1, 0, pid, 2});
}
void Robot::addBuyTask(int buyPlatId, int buyPlatArea, int sellPlatId)
{
  tasks.push({buyPlatId, buyPlatArea, sellPlatId, 1});
}
void Robot::finishCurrentTask()
{
  if (isBuyAction())
  {
    radius = 0.53;
  }
  else if (isSellAction())
  {
    radius = 0.45;
    item = 0;
  }
  tasks.pop();
}
int Robot::get_target()
{
  if (tasks.empty())
    return -2;
  auto &task = tasks.front();
  if (task.action == 1)
    return task.buyPlatId;
  if (task.action == 2)
    return task.sellPlatId;
  return -2;
}
void Robot::fresh()
{
  const double density = 20;
  const double maxF = 250;
  const double maxM = 50;
  radius = item ? 0.53 : 0.45;
  double m = radius * radius * pi * density;
  max_line_acc = maxF / m;
  max_angle_acc = maxM / (m * radius * radius / 2);
}

void Robot::readState()
{
  cin >> pid >> item >> tf >> cf;
  cin >> angle_speed >> v.x >> v.y >> angle;
  cin >> p.x >> p.y;
  // if (id == 1)
  // {
  //     logger.write("Location: " + to_string(id) + ' ' + to_string(p.x) + ' '
  //     + to_string(p.y)); logger.write("item: " + to_string(id) + ' ' +
  //     to_string(item));
  //     // logger.write("Pid: " + to_string(id) + ' ' + to_string(pid));
  // logger.write("id_state_buy_sell_pid: " + to_string(id) + " " +
  // to_string(state) + " " + to_string(mp.plats[buy].type) + " " +
  // to_string(mp.plats[sell].type) + " " + to_string(pid));
  // logger.write("id_state_buy_sell_pid: " + to_string(id) + " " +
  // to_string(state) + " " + to_string(buy) + " " + to_string(sell) + " " +
  // to_string(pid));
  // }
}

double Robot::getcollidedistoline()
{
  double dis = 1e9;
  for (Line &l : edgeLines)
  {
    Line x = {p, Point(cos(angle), sin(angle))};
    Point y = x.inter(l);
    double angle_dis = angle - norm_angle(p.angleto(y));
    angle_dis = norm_angle(angle_dis);
    if (angle_dis >= -pi / 2 && angle_dis <= pi / 2)
      dis = min(dis, p.dis(y));
  }
  return dis;
}

std::pair<D, D> Robot::getNewArgs(const std::vector<Robot> &rs,
                                  const std::vector<Obstacle> &os)
{
  Pt optV =
      HalfplaneBuilder(*this, rs, os, radius + 0.02, TIME_HORIZON, TIME_HORIZON_OBSTACLE)
          .solve(std::fmin(MAX_FORWARD_SPEED,
                           v.len() + MAX_DELTA_LINE_SPEED_PER_FRAME[item > 0]));
  D angleDist = norm_angle(atan2(optV.y, optV.x) - angle);
  D absAngle = std::fabs(angleDist);
  D maxW = std::min(absAngle / TIME_STEP, MAX_ROTATE_SPEED) * sgn(angleDist);
  D maxV = optV.len();
  D eV, eW;

  eW = maxW;
  if (absAngle > PI / 8)
  {
    eV = maxV * 0.1;
  }
  else
  {
    // eV = maxV * std::cos(absAngle);
    eV = maxV;
    eW = maxW * std::sin(absAngle);
  }

  return {eV, eW};
}
// ### Robot end

void setactive()
{
  if (mp.map_id == 1)
  {
    // vector<int> vc = {0, 1, 2, 3, 4, 5, 6, 7, 8, 12, 13, 17, 18, 21, 22, 25,
    // 26, 29, 30, 31, 32, 33, 34, 35, 36}; vector<int> vc = {34, 35}; for (int
    // pid : vc)
    //     mp.plats[pid].active = false;
  }
}

void PreProcess()
{
  logger.Load("logs/log_" + to_string(mp.map_id) + ".txt");
  setactive();
  buildedgeLines();
  buildTaskManager();
}

void ptProcess()
{
  string info = "Sell num for each item:";
  for (int i = 1; i <= 7; ++i)
    info += " " + to_string(sellnum[i]);
  logger.write(info);
  info = "Profit upper bound for each item:";
  for (int i = 1; i <= 7; ++i)
    info += " " + to_string(sellnum[i] * (sell_price[i] - buy_price[i]));
  logger.write(info);

  logger.write("money: " + to_string(money));
  int money_upper_bound = 200000;
  for (int i = 1; i <= 7; ++i)
    money_upper_bound += (sell_price[i] - buy_price[i]) * sellnum[i];
  logger.write("money upper bound: " + to_string(money_upper_bound));
  logger.write("loss money: " + to_string(money_upper_bound - money));
  logger.write("profit rate: " + to_string(1.0 * money / money_upper_bound));
  logger.write("loss rate: " + to_string(1 - 1.0 * money / money_upper_bound));
  logger.write("profit_just_loss_tf: " + to_string(profit_just_loss_tf));
  logger.write("profit_just_loss_cf: " + to_string(profit_just_loss_cf));
}

// void updTask5(vector<Robot> &robots)
// {
//   vector<bool> ok(robots.size());
//   int it = robots.size();
//   if (frameID > max_frame - 400)
//   {
//     for (int i = 0; i < robots.size(); ++i)
//       if (robots[i].isBuyAction() || robots[i].isSellAction())
//         ok[i] = true;
//   }
//   else
//   {
//     for (auto &rob : robots)
//     {
//       if (rob.isBuyAction())
//       {
//         mp.plats[rob.sell].will_buy ^= 1 << mp.plats[rob.buy].sell;
//         --mp.plats[rob.buy].will_sell_num;
//       }
//     }
//   }
//   vector<int> num(10);
//   for (auto &p : mp.plats)
//     if (p.type == 7 && (p.alreay_buy | p.will_buy))
//     {
//       for (int item = 4; item <= 6; ++item)
//         if ((p.need_buy >> item & 1) &&
//             !((p.alreay_buy | p.will_buy) >> item & 1))
//           --num[item];
//       if (p.num == 0 && p.prod_time != -1 && p.prod_time <= 500)
//         for (int item = 4; item <= 6; ++item)
//           --num[item];
//     }
//     else if (p.type >= 4 && p.type <= 6)
//     {
//       int x = p.num + (p.prod_time != -1) - p.will_sell_num;
//       num[p.type] += x;
//     }
//   // int mn = *min_element(num.begin(), num.end());
//   while (it--)
//   {
//     double mxScore = 0;
//     int rid = -1, bpid = -1, spid = -1, rindex = -1, buyPlatArea = -1;
//     for (size_t i = 0; i < robots.size(); ++i)
//     {
//       if (ok[i])
//         continue;
//       auto &rob = robots[i];
//       if (rob.state == 2)
//       {
//         ok[i] = true;
//       }
//       else
//       {
//         for (Platform &bplat : mp.plats)
//         {
//           int nextime = bplat.getnextime();
//           if (nextime == -1 || nextime > 50)
//             continue;

//           // int areas = mp.getPlatAreaNum(bplat.id);
//           // for (int area = areas > 1; area < areas; area++) {
//           for (int area : bplat.validAreas)
//           {
//             D dis1 = max(mp.getEvalDis(rob.p, bplat.id, area, 0.45),
//                          1.0 * nextime / frame_rate * max_line_speed);
//             if (dis1 >= 1e9)
//               continue;
//             for (Platform &splat : mp.plats)
//             {
//               if (splat.can_buy(bplat.sell))
//               {
//                 D dis2 = mp.getEvalDisPP(bplat.id, area, splat.id);
//                 if (dis2 >= 1e9)
//                   continue;
//                 double Score =
//                     (sell_price[bplat.sell] - buy_price[bplat.sell]) /
//                     (dis1 + dis2);

//                 Score *=
//                     __builtin_popcount(splat.will_buy | splat.alreay_buy) + 1;

//                 if (bplat.type >= 1 && bplat.type <= 6 && splat.type == 9)
//                 {
//                   Score /= 10;
//                 }
//                 if (bplat.type >= 4 && bplat.type <= 6 && splat.type == 9 &&
//                     num[bplat.type] <= 1)
//                   Score -= 10000;

//                 if (num[splat.type] < 0)
//                   Score += 10000;

//                 int delta = 25;
//                 double evalTime = frameID +
//                                   (dis1 + dis2) / max_line_speed * frame_rate +
//                                   delta;

//                 // if (bplat.id == 5 && splat.type == 7 && rob.p.y > bplat.p.y)
//                 // {
//                 //   dbg(frameID, area, dis1, dis2, Score);
//                 // }
//                 if (Score > mxScore && evalTime <= max_frame)
//                 {
//                   mxScore = Score;
//                   rid = rob.id;
//                   rindex = i;
//                   bpid = bplat.id;
//                   spid = splat.id;
//                   buyPlatArea = area;
//                 }

//                 // else if (area >= 1 && rid == rob.id && rindex == i && bpid ==
//                 // bplat.id && spid == splat.id && (mxScore - Score) / mxScore <
//                 // EPS) {
//                 //   buyPlatArea |= 1 << area;
//                 // }
//               }
//             }
//           }
//         }
//       }
//     }
//     // logger.write("rid: " + to_string(rid) + " bpid: " + to_string(bpid) + "
//     // spid: " + to_string(spid));
//     // std::cerr << "rid " << rid << ' ' << bpid << ' ' << spid << '\n';
//     if (rid == -1)
//     {
//       for (size_t i = 0; i < robots.size(); ++i)
//         if (robots[i].state == 2)
//           assert(ok[i]);
//         else if (!ok[i])
//         {
//           robots[i].state = 0;
//           robots[i].buy = robots[i].sell = -1;
//         }
//       break;
//     }
//     ok[rindex] = true;
//     auto &rob = robots[rid];

//     auto &bplat = mp.plats[bpid];
//     auto &splat = mp.plats[spid];
//     rob.buy = bpid;
//     rob.sell = spid;
//     rob.buyPlatArea = buyPlatArea;
//     ++bplat.will_sell_num;
//     splat.will_buy |= 1 << bplat.sell;

//     if (splat.need_buy == (splat.will_buy | splat.alreay_buy))
//       ++num[splat.type];
//     rob.state = 1;

//     // if (buyPlatArea > 0) {
//     //   dbg("!!! ", bpid, mp.plats[spid].type, buyPlatArea);
//     // }
//   }
// }

void updTask6(vector<Robot> &robots)
{
  bool transmode = false;
  // if (mp.map_id == 4)
  //     transmode = true;

  vector<bool> ok(robots.size());
  int it = robots.size();
  if (frameID > max_frame - 400)
  {
    for (int i = 0; i < robots.size(); ++i)
      if (robots[i].isBuyAction() || robots[i].isSellAction())
        ok[i] = true;
  }
  else
  {
    for (auto &rob : robots)
    {
      if (rob.isSellAction())
      {
        if (transmode)
          mp.plats[rob.tasks.front().sellPlatId].will_buy ^= 1 << rob.item;
      }
      else if (rob.isBuyAction())
      {
        mp.plats[rob.tasks.front().sellPlatId].will_buy ^= 1 << mp.plats[rob.tasks.front().buyPlatId].sell;
        --mp.plats[rob.tasks.front().buyPlatId].will_sell_num;
        rob.tasks.pop();
        rob.tasks.pop();
      }
    }
  }
  vector<int> num(10);
  for (auto &p : mp.plats)
    if (p.type == 7 && (p.alreay_buy | p.will_buy))
    {
      for (int item = 4; item <= 6; ++item)
        if ((p.need_buy >> item & 1) &&
            !((p.alreay_buy | p.will_buy) >> item & 1))
          --num[item];
      if (p.num == 0 && p.prod_time != -1 && p.prod_time <= 500)
        for (int item = 4; item <= 6; ++item)
          --num[item];
    }
    else if (p.type >= 4 && p.type <= 6)
    {
      int x = p.num + (p.prod_time != -1) - p.will_sell_num;
      num[p.type] += x;
    }
  int mn = *min_element(num.begin(), num.end());
  while (it--)
  {
    double mxScore = 0;
    int rid = -1, bpid = -1, spid = -1, rindex = -1, buyPlatArea = -1;
    for (size_t i = 0; i < robots.size(); ++i)
    {
      auto &rob = robots[i];
      if (!rob.tasks.empty())
        ok[i] = true;
      if (ok[i])
        continue;
      if (rob.isSellAction())
      {
        if (transmode)
          for (auto &splat : mp.plats)
          {
            if (splat.can_buy(rob.item))
            {
              double dis = rob.p.dis(splat.p);
              double Score = sell_price[rob.item] / dis + 100000;

              int delta = 25;
              double evalTime =
                  frameID + dis / max_line_speed * frame_rate + delta;

              if (Score > mxScore && evalTime <= max_frame)
              {
                mxScore = Score;
                rid = rob.id;
                rindex = i;
                bpid = -1;
                spid = splat.id;
              }
            }
          }
        else
          ok[i] = true;
      }
      else
      {
        for (Platform &bplat : mp.plats)
        {
          int nextime = bplat.getnextime();
          if (nextime == -1 || nextime > 50)
            continue;

          for (int area : bplat.validAreas)
          {
            D dis1 = max(mp.getEvalDis(rob.p, bplat.id, area, 0.45),
                         1.0 * nextime / frame_rate * max_line_speed);
            if (dis1 >= 1e9)
              continue;

            for (Platform &splat : mp.plats)
            {
              if (splat.can_buy(bplat.sell))
              {
                // if (!mp.can_to(rob.p, bplat.id, 0.45) ||
                //     !mp.can_to(bplat.p, splat.id, 0.53))
                //   continue;

                // double edis = mp.getEvalDis(rob.p, bplat.id, 0.45);

                // double dis1 =
                //     max(edis, 1.0 * nextime / frame_rate * max_line_speed);
                // double dis2 = mp.getEvalDisPP(
                //     bplat.id,
                //     splat.id); // mp.getEvalDis(bplat.p, splat.id, 0.53);
                D dis2 = mp.getEvalDisPP(bplat.id, area, splat.id);
                if (dis2 >= 1e9)
                  continue;

                double Score =
                    (sell_price[bplat.sell] - buy_price[bplat.sell]) /
                    (dis1 + dis2);

                Score *= pow(
                    __builtin_popcount(splat.will_buy | splat.alreay_buy) + 1,
                    1.5);

                if (bplat.type >= 1 && bplat.type <= 6 && splat.type == 9)
                  Score /= 10;

                if (bplat.type >= 4 && bplat.type <= 6 && splat.type == 9 &&
                    num[bplat.type] <= 1)
                  Score -= 10000;

                Score -= __builtin_popcount(bplat.will_buy) * 1000;

                if (num[splat.type] < 0)
                  Score += 10000;

                // logger.write("SC: " + to_string(Score));
                int delta = 25;
                double evalTime = frameID +
                                  (dis1 + dis2) / max_line_speed * frame_rate +
                                  delta;

                if (Score > mxScore && evalTime <= max_frame)
                {
                  mxScore = Score;
                  rid = rob.id;
                  rindex = i;
                  bpid = bplat.id;
                  spid = splat.id;
                  buyPlatArea = area;
                }
              }
            }
          }
        }
      }
    }
    // logger.write("rid: " + to_string(rid) + " bpid: " + to_string(bpid) + "
    // spid: " + to_string(spid));
    if (rid == -1)
    {
      for (size_t i = 0; i < robots.size(); ++i)
        if (robots[i].isBuyAction())
          assert(ok[i]);
        else if (!ok[i])
          robots[i].fresh();
      break;
    }
    ok[rindex] = true;
    auto &rob = robots[rid];
    if (rob.item)
    {
      assert(rob.state == 2);
      auto &splat = mp.plats[spid];
      rob.addSellTask(spid);
      splat.will_buy |= 1 << rob.item;
    }
    else
    {
      auto &bplat = mp.plats[bpid];
      auto &splat = mp.plats[spid];
      rob.addBuyTask(bpid, buyPlatArea, spid);
      rob.addSellTask(spid);
      ++bplat.will_sell_num;
      splat.will_buy |= 1 << bplat.sell;
      if (splat.need_buy == (splat.will_buy | splat.alreay_buy))
        ++num[splat.type];
    }
  }
}

// void updTask7(vector<Robot> &robots)
// {
//   // map1 96w
//   bool transmode = false;
//   // if (mp.map_id == 4)
//   //     transmode = true;

//   vector<bool> ok(robots.size());
//   int it = robots.size();
//   if (frameID > max_frame - 400)
//   {
//     for (int i = 0; i < robots.size(); ++i)
//       if (robots[i].state)
//         ok[i] = true;
//   }
//   else
//   {
//     for (auto &rob : robots)
//     {
//       if (rob.state == 2)
//       {
//         if (transmode)
//           mp.plats[rob.sell].will_buy ^= 1 << rob.item;
//       }
//       else if (rob.state == 1)
//       {
//         mp.plats[rob.sell].will_buy ^= 1 << mp.plats[rob.buy].sell;
//         --mp.plats[rob.buy].will_sell_num;
//       }
//     }
//   }
//   vector<int> num(10);
//   for (auto &p : mp.plats)
//     if (p.type == 7 && (p.alreay_buy | p.will_buy))
//     {
//       for (int item = 4; item <= 6; ++item)
//         if ((p.need_buy >> item & 1) &&
//             !((p.alreay_buy | p.will_buy) >> item & 1))
//           --num[item];
//       if (p.num == 0 && p.prod_time != -1 && p.prod_time <= 500)
//         for (int item = 4; item <= 6; ++item)
//           --num[item];
//     }
//     else if (p.type >= 4 && p.type <= 6)
//     {
//       int x = p.num + (p.prod_time != -1) - p.will_sell_num;
//       num[p.type] += x;
//     }
//   int mn = *min_element(num.begin(), num.end());
//   while (it--)
//   {
//     double mxScore = 0;
//     int rid = -1, bpid = -1, spid = -1, rindex = -1, buyPlatArea = -1;
//     for (size_t i = 0; i < robots.size(); ++i)
//     {
//       if (ok[i])
//         continue;
//       auto &rob = robots[i];
//       if (rob.state == 2)
//       {
//         if (transmode)
//           for (auto &splat : mp.plats)
//           {
//             if (splat.can_buy(rob.item))
//             {
//               double dis = rob.p.dis(splat.p);
//               double Score = sell_price[rob.item] / dis + 100000;

//               int delta = 25;
//               double evalTime =
//                   frameID + dis / max_line_speed * frame_rate + delta;

//               if (Score > mxScore && evalTime <= max_frame)
//               {
//                 mxScore = Score;
//                 rid = rob.id;
//                 rindex = i;
//                 bpid = -1;
//                 spid = splat.id;
//               }
//             }
//           }
//         else
//           ok[i] = true;
//       }
//       else
//       {
//         for (Platform &bplat : mp.plats)
//         {
//           int nextime = bplat.getnextime();
//           if (nextime == -1 || nextime > 50)
//             continue;
//           for (int area : bplat.validAreas)
//           {
//             D dis1 = max(mp.getEvalDis(rob.p, bplat.id, area, 0.45),
//                          1.0 * nextime / frame_rate * max_line_speed);
//             if (dis1 >= 1e9)
//               continue;

//             for (Platform &splat : mp.plats)
//             {
//               if (splat.can_buy(bplat.sell))
//               {
//                 // if (!mp.can_to(rob.p, bplat.id, 0.45) ||
//                 //     !mp.can_to(bplat.p, splat.id, 0.53))
//                 //   continue;

//                 // double edis = mp.getEvalDis(rob.p, bplat.id, 0.45);

//                 // double dis1 =
//                 //     max(edis, 1.0 * nextime / frame_rate * max_line_speed);
//                 // double dis2 = mp.getEvalDisPP(
//                 //     bplat.id,
//                 //     splat.id); // mp.getEvalDis(bplat.p, splat.id, 0.53);

//                 D dis2 = mp.getEvalDisPP(bplat.id, area, splat.id);
//                 if (dis2 >= 1e9)
//                   continue;

//                 double Score =
//                     (sell_price[bplat.sell] - buy_price[bplat.sell]) /
//                     (dis1 + dis2);

//                 Score *= pow(
//                     __builtin_popcount(splat.will_buy | splat.alreay_buy) + 1,
//                     1.5);

//                 if (bplat.type >= 1 && bplat.type <= 6 && splat.type == 9)
//                   Score /= 10;

//                 if (bplat.type >= 4 && bplat.type <= 6 && splat.type == 9 &&
//                     num[bplat.type] <= 1)
//                   Score -= 10000;

//                 Score -= __builtin_popcount(bplat.will_buy) * 1000;

//                 if (num[splat.type] < 0)
//                   Score += 10000;

//                 // logger.write("SC: " + to_string(Score));
//                 int delta = 25;
//                 double evalTime = frameID +
//                                   (dis1 + dis2) / max_line_speed * frame_rate +
//                                   delta;

//                 if (Score > mxScore && evalTime <= max_frame)
//                 {
//                   mxScore = Score;
//                   rid = rob.id;
//                   rindex = i;
//                   bpid = bplat.id;
//                   spid = splat.id;
//                   buyPlatArea = area;
//                 }
//               }
//             }
//           }
//         }
//       }
//     }
//     // logger.write("rid: " + to_string(rid) + " bpid: " + to_string(bpid) + "
//     // spid: " + to_string(spid));
//     if (rid == -1)
//     {
//       for (size_t i = 0; i < robots.size(); ++i)
//         if (robots[i].state == 2)
//           assert(ok[i]);
//         else if (!ok[i])
//         {
//           robots[i].state = 0;
//           robots[i].buy = robots[i].sell = -1;
//         }
//       break;
//     }
//     ok[rindex] = true;
//     auto &rob = robots[rid];
//     if (rob.item)
//     {
//       assert(rob.state == 2);
//       auto &splat = mp.plats[spid];
//       rob.sell = spid;
//       splat.will_buy |= 1 << rob.item;
//     }
//     else
//     {
//       auto &bplat = mp.plats[bpid];
//       auto &splat = mp.plats[spid];
//       rob.buy = bpid;
//       rob.sell = spid;
//       rob.buyPlatArea = buyPlatArea;
//       ++bplat.will_sell_num;
//       splat.will_buy |= 1 << bplat.sell;
//       if (splat.need_buy == (splat.will_buy | splat.alreay_buy))
//         ++num[splat.type];
//       rob.state = 1;
//     }
//   }
// }
void updTask(vector<Robot> &robots)
{
  // updTask1(robots);
  // updTask2(robots);
  // if (mp.map_id == 1)
  //   updTask3(robots);
  // else
  updTask6(robots);
}

void RVO_move(vector<Robot> &robots)
{
  for (Platform &p : mp.plats)
    p.fresh_visit();
  for (Robot &rob : robots)
  {
    rob.fresh();
    rob.wait = false;
    int target = rob.get_target();
    if (target != -2 && mp.getEvalDis(rob) <= 6)
      mp.plats[target].apply_visit(rob.id);
  }
  for (Platform &p : mp.plats)
    p.process_apply_visit_list();

  if (mp.map_id == 1)
  {
    for (Robot &rob : robots)
    {
      int target = rob.get_target();
      if (target != -2 && mp.getEvalDis(rob) <= 6 &&
          mp.plats[target].visit_robot_id != rob.id)
        rob.wait = true;
    }
  }

  std::vector<Point> pref(robots.size());
  for (auto &r : robots)
  {
    int target = r.get_target();
    double maxSpeed = max_line_speed;
    if (r.wait)
      maxSpeed *= 0.05;
    Point p = r.next_to - r.p;
    double d = p.len();
    if (target >= 0)
      d = r.p.dis(mp.plats[target].p);
    if (p.len() <= 1e-8)
      pref[r.id] = Point(0, 0);
    else
      pref[r.id] = p / p.len() * min(maxSpeed, max(0.1, d) / 0.1225);
  }

  for (auto &i : robots)
  {

    i.preferredVelocity = pref[i.id];
  }

  for (auto &r : robots)
  {
    double eV, eW;

    auto os = Obstacle::getNearbyObstacles(mp.origin_map, r.p, 5);
    tie(eV, eW) = r.getNewArgs(robots, os);

    if (mp.map_id != 1)
    {
      double disToRob = 1e9;
      for (auto &rb : robots)
        if (rb.id != r.id)
        {
          double angle_dis = norm_angle(r.angle - r.p.angleto(rb.p));
          if (abs(angle_dis) <= pi / 2)
            disToRob = min(disToRob, r.p.dis(rb.p) - r.radius - rb.radius);
        }

      if (disToRob <= 0.8)
        eV = min(eV, disToRob);
    }

    cout << "forward " << r.id << " " << eV << "\n";
    cout << "rotate " << r.id << " " << eW << "\n";
  }
}

void move(vector<Robot> &robots)
{
  static vector<int> ids;

  if (ids.empty())
  {
    ids.resize(robots.size());
    iota(ids.begin(), ids.end(), 0);
  }

  // std::vector<D> va(robots.size());
  // for (auto &r : robots) {
  //   va[r.id] =
  //       HalfplaneBuilder(r, robots,
  //                        Obstacle::getNearbyObstacles(mp.origin_map, r.p, 5),
  //                        0.6,
  //                        1, 1)
  //           .getArea(MAX_FORWARD_SPEED);
  // }

  // const D THR = 6;
  stable_sort(ids.begin(), ids.end(), [&](int x, int y)
              {
    // if (std::min(va[x], va[y]) < THR) {
    //   // if (std::fabs(va[x] - va[y]) >= THR) {
    //   return va[x] + 0.15 < va[y];
    // }
    // return va[x] < va[y];
    // return robots[x].item > robots[y].item;
    if (robots[x].item != robots[y].item)
      return robots[x].item > robots[y].item;
    return x < y; });

  // if (frameID % 100 == 0) {
  //   static std::mt19937 rng(123);
  //   shuffle(ids.begin(), ids.end(), rng);
  //   // dbg(ids[0]);
  //   // for (int i : ids) {
  //   //   dbg(i, robots[i].p.str(), va[i]);
  //   // }
  // }

  vector<Segment> segs;
  for (int id : ids)
  {
    auto &r = robots[id];
    int pid = r.get_target();
    r.next_to = mp.getNextTo(r.p, pid, r.isBuyAction() ? r.tasks.front().buyPlatArea : 0,
                             r.radius, segs);

    Pt u = r.p, v = r.next_to - u;
    if (v.len() < 0.001)
    {
      segs.push_back({u, u});
    }
    else
    {
      segs.push_back(
          {u - v.unit() * r.radius,
           u + v.unit() *
                   (r.radius +
                    std::min(v.len(),
                             (r.v.len() +
                              MAX_DELTA_LINE_SPEED_PER_FRAME[r.item > 0]) /
                                 FPS))});
    }
  }

  RVO_move(robots);
}

void sellItem(vector<Robot> &robots)
{
  for (Robot &r : robots)
  {
    if (r.tasks.empty())
      continue;
    auto &task = r.tasks.front();
    if (r.isSellAction() && r.pid == task.sellPlatId)
    {
      bool ok = mp.plats[r.pid].buyitem(r.item);
      if (ok)
      {
        ++sellnum[r.item];
        profit_just_loss_tf += sell_price[r.item] * r.tf;
        profit_just_loss_cf += sell_price[r.item] * r.cf;
        r.finishCurrentTask();
        cout << "sell " << r.id << '\n';
      }
    }
  }
}
void buyItem(vector<Robot> &robots)
{
  for (Robot &r : robots)
  {
    if (r.tasks.empty())
      continue;
    auto &task = r.tasks.front();
    if (r.isBuyAction() && r.pid == task.buyPlatId)
    {
      if (task.buyPlatArea && !checkPointArea(task.buyPlatArea, r.p - mp.plats[task.buyPlatId].p))
        continue;

      double evalTime = frameID +
                        mp.plats[task.buyPlatId].p.dis(mp.plats[task.sellPlatId].p) /
                            max_line_speed * frame_rate +
                        15;
      if (evalTime > max_frame)
        continue;

      r.item = mp.plats[r.pid].sellitem();
      if (r.item != 0)
      {
        profit_just_loss_tf -= buy_price[r.item];
        profit_just_loss_cf -= buy_price[r.item];
        cout << "buy " << r.id << '\n';
        r.finishCurrentTask();
        // logger.write("buy: " + to_string(item) + " plat_sell: " +
        // to_string(mp.plats[pid].sell) + " plat_type: " +
        // to_string(mp.plats[pid].type));
      }
    }
  }
}

int main()
{
#ifdef TEST
  freopen("../../maps/3.txt", "r", stdin);
#endif

  ios::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);

  readmap();
  PreProcess();

#ifdef TEST
  // cout << mp.geths() << '\n';
  // return 0;
  logger.write("PreProcess time: " + to_string(timeCounter.getTime()) + "ms");
  for (int j = mp.gm - 1; j >= 0; --j)
  {
    auto g = [&](int x, int len)
    {
      string s = to_string(x);
      if (x == -1)
        s = "*****";
      while (int(s.size()) < len)
        s = ' ' + s;
      return s;
    };
    string info;
    for (int i = 0; i < mp.gn; ++i)
    {
      int num = mp.dis53[5][i][j];
      if (num == inf)
        num = -1;
      info += g(num, 5) + " ";
    }
    logger.write(info);
  }
  exit(0);
#endif

  readok();
  cout << "OK\n";
  cout.flush();

  std::cerr << "init OK, time " << timeCounter.getTime() << "\n";

  while (cin >> frameID)
  {
    // logger.write("Frame: " + to_string(frameID));
    cin >> money;
    int K;
    cin >> K;
    assert(K == mp.plats.size());
    for (Platform &plat : mp.plats)
      plat.readState();
    for (Robot &rob : mp.robots)
      rob.readState();
    for (int i = 0; i < 4; ++i)
    {
      double x;
      for (int j = 0; j < 360; ++j)
        cin >> x;
    }

    readok();

    cout << frameID << '\n';
    sellItem(mp.robots);
    updTask(mp.robots);
    buyItem(mp.robots);
    move(mp.robots);
    cout << "OK\n";
    cout.flush();
  }
  ptProcess();
  return 0;
}
