#pragma once
#include "Geometry.hpp"
#include "obstacle.hpp"

struct Task
{
  int buyPlatId;   // 物品从哪个平台购买
  int buyPlatArea; // 执行购买动作时工作台的判断区域，buyPlatArea=0表示不限制任何区域
  int sellPlatId;  // 物品卖往哪个平台
  /*
  action=0 达到目的地不执行买卖动作
  action=1 到达目的地后执行买动作，目的地是buyPlatId
  action=2 到达目的地后执行卖动作，目的地是sellPlatId
  */
  int action;
};

class Robot
{
public:
  const int id;
  int pid;  // 当前所在工作台id
  int item; // 携带物品类型
  Point p;
  Point next_to;
  Point preferredVelocity;
  double radius;
  double angle;
  double line_speed;
  Point v; // 速度
  double angle_speed;
  double tf; // 时间系数
  double cf; // 碰撞系数
  double rotangle;
  int rotframe;
  double max_angle_acc;
  double max_line_acc;
  bool wait;
  std::queue<Task> tasks;
  Robot(int id, double x, double y) : id(id)
  {
    pid = -1;
    item = 0;
    radius = 0.45;
    angle = 0;
    line_speed = 0;
    v = Point(0, 0);
    angle_speed = 0;
    tf = cf = 0;

    this->p.x = x;
    this->p.y = y;
    rotangle = rotframe = 0;
  }
  void readState();
  double getcollidedistoline();
  void fresh();
  int get_target();
  void finishCurrentTask();
  void addSellTask(int);
  void addBuyTask(int, int, int);
  inline bool isBuyAction();
  inline bool isSellAction();

  std::pair<D, D> getNewArgs(const std::vector<Robot> &,
                             const std::vector<Obstacle> &);
};